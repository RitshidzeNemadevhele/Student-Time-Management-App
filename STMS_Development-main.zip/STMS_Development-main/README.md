# STMS_Development

## Prerequisite

1. Your ip address is whitelisted, so that you are able to make changes to the database
   (Contact me at bhekananicele@gmail.com to get your ip address whitelisted)
3. Node.Js is installed on your computer.

## Getting Started (Assuming you already have the project)

1. Change directory to STMS_Development.
2. Open two terminals on the current directory(STMS_Development)
3. Change directory to client on the first terminal.
4. Change directory to server on the second terminal.
5. On both the terminals type: ```npm install``` and press enter to install the necessary dependencies.
6. Once the installation is complete on both terminals. 
8. On both the terminals type: ```npm start``` and press enter to run the web application.
9. Congratulations! Your browser will open, now you can use the web application.



