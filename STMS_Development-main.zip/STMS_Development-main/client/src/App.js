import React from "react";
import "./styles/App.css";
import "./styles/TodoList.css";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import PrivateRoute, {
  RouteRedirect,
  PublicRoute,
} from "./components/Auth/PrivateRoute";
import Login from "./pages/Login";
import SignUp from "./pages/SignUp";
import Home from "./pages/Home";
import Scheduler from "./pages/Scheduler";
import TodoList from "./pages/TodoList";
import Notifications from "./pages/Notifications";
import Settings from "./pages/Settings";
import PageNotFound from "./pages/PageNotFound";

/*
Main App - React Component
*/
function App() {
  return (
    <>
      <Router>
        <Switch>
          {/* Private Route - Home Page*/}
          <PrivateRoute
            redirectPath="/User/Login"
            path="/"
            exact
            component={Home}
          />

          <PrivateRoute
            redirectPath="/User/Login"
            path="/Home"
            exact
            component={Home}
          />

          {/* Private Route - Scheduler Page*/}
          <PrivateRoute
            redirectPath="/User/Login"
            path="/User/Scheduler"
            exact
            component={Scheduler}
          />

          {/* Private Route - TodoList Page*/}
          <PrivateRoute
            redirectPath="/User/Login"
            path="/User/TodoList"
            exact
            component={TodoList}
          />

          {/* Private Route - Notification Page*/}
          <PrivateRoute
            redirectPath="/User/Login"
            path="/User/Notifications"
            exact
            component={Notifications}
          />

          {/* Private Route - Settings Page*/}
          <PrivateRoute
            redirectPath="/User/Login"
            path="/User/Settings"
            exact
            component={Settings}
          />

          {/* Redirect Route - Login/Signin Route*/}
          <RouteRedirect redirectPath="/User/Login" path="/login" />
          <RouteRedirect redirectPath="/User/SignUp" path="/signup" />

           {/* Public Route - Login Page*/}
          <PublicRoute
            redirectPath="/"
            path="/User/Login"
            exact
            component={Login}
          />

          {/* Public Route - SignUp Page*/}
          <PublicRoute
            redirectPath="/"
            path="/User/SignUp"
            exact
            component={SignUp}
          />

          {/* Route - PageNotFound Page*/}
          <Route component={PageNotFound} />
        </Switch>
      </Router>
    </>
  );
}

export default App;
