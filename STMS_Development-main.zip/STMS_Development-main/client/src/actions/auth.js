import { AUTH } from "../constants/actionTypes";
import * as api from "../api/index.js";

/*
Action called when a user request to sign in 
*/
export const signup = (formData, history) => async (dispatch) => {
  try {
    const { data } = await api.signUp(formData);
    dispatch({ type: AUTH, data });
    history.push("/");
  } catch (error) {
    return error?.response?.data?.message;
  }
};

/*
Action called when a user request to login 
*/
export const login = (formData, history) => async (dispatch) => {
  try {
    const { data } = await api.logIn(formData);
    dispatch({ type: AUTH, data });
    history.push("/");
  } catch (error) {
    return error?.response?.data?.message;
  }
};
/*
Action called when a user request to login/signup using Google 
*/
export const googleLogInSignUp = (profile, history) => async (dispatch) => {
  try {
    await api.googleLoginSignup(profile);
    history.push("/");
  } catch (error) {
    return error?.response?.data?.message;
  }
};
