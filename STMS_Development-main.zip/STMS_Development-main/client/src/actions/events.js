import { CREATE, FETCH_ALL } from "../constants/actionTypes";
import * as api from "../api/index.js";
import { deleteNotification } from "./notifications";
import { deleteToDoList } from "./todolist";

/*
Action called to get events of the user from the database
*/
export const getEvents = (userId) => async (dispatch) => {
  try {
    const { data } = await api.fetchEvents({ userId });
    dispatch({ type: FETCH_ALL, payload: data });
  } catch (error) {
    console.log(error);
  }
};

/*
Action called to create an event of the user on the database
*/
export const createEvent = (event) => async (dispatch) => {
  try {
    const { data } = await api.createEvent(event);
    dispatch({ type: CREATE, payload: data });
  } catch (error) {
    console.log(error);
  }
};

/*
Action called to delete an event of the user from the database
*/
export const deleteEvent = (event) => async (dispatch) => {
  try {
    await api.deleteEvent(event);
    dispatch(getEvents(event?.userId));
    dispatch(deleteToDoList(event.id));
    dispatch(deleteNotification(event));
  } catch (error) {
    console.log(error);
  }
};

/*
Action called to update an event of the user on the database
*/
export const changeEvent = (event) => async (dispatch) => {
  try {
    await api.changeEvent(event);
    dispatch(getEvents(event?.userId));
    if (event.todoListAddId === 0) dispatch(deleteToDoList(event.id));
    dispatch(deleteNotification(event));
  } catch (error) {
    console.log(error);
  }
};
