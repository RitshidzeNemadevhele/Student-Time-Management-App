import {
  CREATE_NOTIFICATION,
  FETCH_ALL_NOTIFICATIONS,
} from "../constants/actionTypes";
import * as api from "../api/index.js";

/*
Action called to get user notification from the database
*/
export const getNotifications = (userId) => async (dispatch) => {
  try {
    const { data } = await api.fetchNotifications({ userId });
    dispatch({ type: FETCH_ALL_NOTIFICATIONS, payload: data });
  } catch (error) {
    console.log(error);
  }
};

/*
Action called to create user notification on the database
*/
export const createNotification = (notification) => async (dispatch) => {
  try {
    const { data } = await api.createNotification(notification);
    if (data !== null) {
      dispatch({ type: CREATE_NOTIFICATION, payload: data });
    }
  } catch (error) {
    console.log(error);
  }
};

/*
Action called to delete user notification from the database
*/
export const deleteNotification = (notification) => async (dispatch) => {
  try {
    await api.deleteNotification(notification);
    dispatch(getNotifications(notification?.userId));
  } catch (error) {
    console.log(error);
  }
};

/*
Action called to update user notification on the database
*/
export const changeNotification = (notification) => async (dispatch) => {
  try {
    await api.changeNotification(notification);
    dispatch(getNotifications(notification?.userId));
  } catch (error) {
    console.log(error);
  }
};
