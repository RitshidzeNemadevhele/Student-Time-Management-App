import { FETCH_SETTINGS } from "../constants/actionTypes";
import * as api from "../api/index.js";

/*
Action called to get user settings from the database
*/
export const getSettings = (userId) => async (dispatch) => {
  try {
    const { data } = await api.fetchSettings({ userId });
    dispatch({ type: FETCH_SETTINGS, payload: data });
  } catch (error) {
    console.log(error);
  }
};

/*
Action called to create user settings on the database
*/
export const createSettings = (settings) => async (dispatch) => {
  try {
    const { data } = await api.createSettings(settings);
      dispatch(getSettings(settings?.userId));
    return data
  } catch (error) {
    return error?.response?.data?.message;
  }
};

/*
Action called to update user settings on the database
*/
export const changeSettings = (settings) => async (dispatch) => {
  try {
    const {data} = await api.changeSettings(settings);
    dispatch(getSettings(settings?.userId));
    return data;
  } catch (error) {
    return error?.response?.data?.message;
  }
};
