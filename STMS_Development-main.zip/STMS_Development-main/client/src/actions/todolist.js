import { FETCH_ALL_TODOLIST, CREATE_TODOLIST } from "../constants/actionTypes";
import * as api from "../api/index.js";

/*
Action called to get todo list of the user from the database
*/
export const getToDoList = (userId) => async (dispatch) => {
  try {
    const { data } = await api.fetchToDoList({ userId });
    dispatch({ type: FETCH_ALL_TODOLIST, payload: data });
  } catch (error) {
    console.log(error);
  }
};

/*
Action called to create a todolist of the user on the database
*/
export const createToDoList = (todolist) => async (dispatch) => {
  try {
    const { data } = await api.createToDoList(todolist);
    dispatch({ type: CREATE_TODOLIST, payload: data });
  } catch (error) {
    console.log(error);
  }
};

/*
Action called to update todo list of the user on the database
*/
export const changeToDoList = (todolist) => async (dispatch) => {
  try {
    await api.changeToDoList(todolist);
    dispatch(getToDoList(todolist?.userId));
  } catch (error) {
    console.log(error);
  }
};

/*
Action called to delete a todo list item of the user from the database
*/
export const deleteToDoList = (id) => async (dispatch) => {
  try {
    let todolist = JSON.parse(localStorage.getItem("todolists"))?.filter(
      () => true
    )[0];
    if (todolist !== undefined) {
      todolist.items = todolist.items?.filter((item) => item.id !== id);
      dispatch(changeToDoList(todolist));
    }
  } catch (error) {
    console.log(error);
  }
};
