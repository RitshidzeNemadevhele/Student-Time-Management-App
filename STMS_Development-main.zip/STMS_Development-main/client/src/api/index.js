import axios from "axios";

const API = axios.create({ baseURL: "http://localhost:5000" });

// Api post methods to authenticate the user 
export const logIn = (formData) => API.post("user/login", formData);
export const signUp = (formData) => API.post("user/signup", formData);
export const googleLoginSignup = (profile) => API.post("user/google/login", profile);

// Api post methods to manage the user events
export const fetchEvents = (userId) => API.post("User/GetEvents", userId);
export const createEvent = (newEvent) => API.post("User/CreateEvent", newEvent);
export const deleteEvent = (event) => API.post("User/DeleteEvent", event);
export const changeEvent = (event) => API.post("User/ChangeEvent", event);

// Api post methods to manage the user notifications
export const fetchNotifications = (userId) => API.post("User/GetNotifications", userId);
export const createNotification = (newNotification) => API.post("User/CreateNotification", newNotification);
export const deleteNotification = (notification) => API.post("User/DeleteNotification", notification);
export const changeNotification = (notification) => API.post("User/ChangeNotification", notification);

// Api post methods to manage the user todo list
export const fetchToDoList = (userId) => API.post("User/GetToDoList", userId);
export const createToDoList = (newToDoList) => API.post("User/CreateToDoList", newToDoList)
export const changeToDoList = (todolist) => API.post("User/ChangeToDoList", todolist)

// Api post methods to manage the user settings
export const fetchSettings = (userId) => API.post("User/GetSettings", userId);
export const createSettings = (newSettings) => API.post("User/CreateSettings", newSettings);
export const changeSettings = (settings) => API.post("User/ChangeSettings", settings);