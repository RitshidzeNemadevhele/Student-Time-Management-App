import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import { Alert, AlertTitle } from "@material-ui/lab";
import { ERROR, WARNING, INFO } from "../../constants/actionTypes";

var thisWidth = "100%";
// Material UI Styles
const useStyles = makeStyles((theme) => ({
  root: {
    width: thisWidth,
    "& > * + *": {
      marginTop: theme.spacing(2),
    },
  },
}));

/*
Alert React Component
*/
export default function DescriptionAlerts({
  alertType,
  message,
  title,
  handleCloseAlert,
}) {
  const classes = useStyles();

  //Method to get a specific alert
  function getAlert(alertType, message, title) {
    switch (alertType) {
      case ERROR:
        return (
          // Error Alert
          <Alert
            severity="error"
            onClose={() => {
              handleCloseAlert();
            }}
          >
            <AlertTitle>{title}</AlertTitle>
            {message}
          </Alert>
        );
      case WARNING:
        return (
           // Warning Alert
          <Alert
            severity="warning"
            onClose={() => {
              handleCloseAlert();
            }}
          >
            <AlertTitle>{title}</AlertTitle>
            {message}
          </Alert>
        );

      case INFO:
        return (
           // Information Alert
          <Alert
            severity="info"
            onClose={() => {
              handleCloseAlert();
            }}
          >
            <AlertTitle>{title}</AlertTitle>
            {message}
          </Alert>
        );

      default:
        return (
          <Alert
            //Success alert 
            severity="success"
            onClose={() => {
              handleCloseAlert();
            }}
          >
            <AlertTitle>{title}</AlertTitle>
            {message}
          </Alert>
        );
    }
  }
  return (
    <div className={classes.root}>{getAlert(alertType, message, title)}</div>
  );
}
