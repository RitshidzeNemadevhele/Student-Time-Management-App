import React, { useState } from "react";
import { useHistory } from "react-router";
import "../../styles/Auth.css";
import FormSignup from "./FormSignup";
import { useDispatch } from "react-redux";
import { signup, login } from "../../actions/auth";
import Alert from "../Alert/Alert";
import { Box, Paper } from "@material-ui/core";
import TimeTracking from "../../images/TimeTracking.jpg";
var alertType;
var alertMessage;
var alertTitle;

/*
Login/Sign Form React Component
*/
const Form = ({ isSignUp }) => {
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [showAlert, setShowAlert] = useState(false);
  const [signUp] = useState(isSignUp);
  const [formData, setFormData] = useState({});
  const history = useHistory();
  const dispatch = useDispatch();

  //Method to convert a string to a title case
  const toTitleCase = (string) => {
    return string.replace(/\w\S*/g, function (txt) {
      return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
    });
  };

  // Method to handle submit event
  function submitForm(formDataArg) {
    setIsSubmitted(true);
    setFormData(formDataArg);
  }

  // Method to close the alert component
  function handleClosingAlert() {
    setShowAlert(false);
  }

  // Method to handle submit button event
  const handleSubmit = () => {
    if (signUp) {
      dispatch(signup(formData, history)).then(function (response) {
        if (Array.isArray(response)) {
          alertTitle = toTitleCase(response[2]);
          alertType = response[2];
          alertMessage = response[0];
          setShowAlert(false);
          setShowAlert(true);
        }
      });
    } else {
      dispatch(login(formData, history)).then(function (response) {
        if (Array.isArray(response)) {
          alertTitle = toTitleCase(response[2]);
          alertType = response[2];
          alertMessage = response[0];
          setShowAlert(false);
          setShowAlert(true);
        }
      });
    }
    setIsSubmitted(false);
  };

  return (
    <>
      <Box display="flex" justifyContent="center">
        <Paper>
          {showAlert ? (
            <Alert
              alertType={alertType}
              message={alertMessage}
              title={alertTitle}
              handleCloseAlert={handleClosingAlert}
            />
          ) : null}
        </Paper>
      </Box>
      <div className={signUp ? "form-container" : "form-container login"}>
        <div className="form-content-left">
          <img className="form-img" src={TimeTracking} alt="Time Management" />
        </div>
        <FormSignup submitForm={submitForm} signUp={signUp} />
        {!isSubmitted ? null : handleSubmit()}
      </div>
    </>
  );
};

export default Form;
