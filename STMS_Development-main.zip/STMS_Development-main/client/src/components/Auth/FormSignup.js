import dotenv from "dotenv";
import React from "react";
import validate from "./validateInfo";
import useForm from "./useForm";
import { FcGoogle } from "react-icons/fc";
import "../../styles/Auth.css";
import { GoogleLogin } from "react-google-login";
import { useDispatch } from "react-redux";
import { AUTH } from "../../constants/actionTypes";
import { useHistory } from "react-router";
import { googleLogInSignUp } from "../../actions/auth";
dotenv.config({ silent: process.env.NODE_ENV === 'production' });

const iconSize = 30;

/*
Login/SignUp Form React Component
*/
const FormSignup = ({ submitForm, signUp }) => {
  const { handleChange, handleSubmit, values, errors } = useForm(
    submitForm,
    validate,
    signUp
  );
  const dispatch = useDispatch();
  const history = useHistory();

  //Method callaed when google login/signup was successful
  const googleSuccess = async (res) => {
    const profile = res?.profileObj;
    const token = res?.tokenId;
    try {
      dispatch({ type: AUTH, data: { profile, token } });
      dispatch(googleLogInSignUp(profile, history));
    } catch (error) {
      console.log(error);
    }
  };
  //Method called when google login/signup was Unsuccessful
  const googleFailure = () => {
    console.log("Google Sign Was Unsuccessful");
  };

  return (
    <div className="form-content-right">
      <form onSubmit={handleSubmit} className="form" noValidate>
        <h1>Student Time Management System</h1>
        <h1 className="login-signup">{signUp ? "Sign up" : "Login"}</h1>
        {/* Login/Signup Form Fields*/}
        {signUp ? (
          <div className="form-inputs">
            <label className="form-label">Name and Surname</label>
            <input
              className="form-input"
              type="text"
              name="username"
              placeholder="Enter your name and surname"
              value={values.username}
              onChange={handleChange}
            />
            {errors.username && <p>{errors.username}</p>}
          </div>
        ) : null}
        <div className="form-inputs">
          <label className="form-label">Email</label>
          <input
            className="form-input"
            type="email"
            name="email"
            placeholder="Enter your email"
            value={values.email}
            onChange={handleChange}
          />
          {errors.email && <p>{errors.email}</p>}
        </div>
        <div className="form-inputs">
          <label className="form-label">Password</label>
          <input
            className="form-input"
            type="password"
            name="password"
            placeholder="Enter your password"
            value={values.password}
            onChange={handleChange}
          />
          {errors.password && <p>{errors.password}</p>}
        </div>
        {signUp ? (
          <div className="form-inputs">
            <label className="form-label">Confirm Password</label>
            <input
              className="form-input"
              type="password"
              name="password2"
              placeholder="Confirm your password"
              value={values.password2}
              onChange={handleChange}
            />
            {errors.password2 && <p>{errors.password2}</p>}
          </div>
        ) : null}
        <br />
        <button className="form-input-btn" type="submit">
          {signUp ? "Sign Up" : "Log In"}
        </button>
        <span className="or">--------------- OR ---------------</span>

        {/* Google Login/Signup Button*/}
        <GoogleLogin
          clientId={process.env.REACT_APP_CLIENT_ID}
          render={(renderProps) => (
            <button
              className="form-input-btn"
              onClick={renderProps.onClick}
              disabled={renderProps.disabled}
            >
              <FcGoogle size={iconSize} />
              {signUp ? "Sign up with Google" : "Log in with Google"}
            </button>
          )}
          onSuccess={googleSuccess}
          onFailure={googleFailure}
          cookiePolicy="single_host_origin"
        />

        {signUp ? (
          <span className="form-input-login">
            Already have an account? <a href="/Login">Log in</a>
          </span>
        ) : (
          <span className="form-input-login">
            Don't have an account? <a href="/SignUp">Create Account</a>
          </span>
        )}
      </form>
    </div>
  );
};

export default FormSignup;
