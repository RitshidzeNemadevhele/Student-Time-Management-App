import React, { useState, useEffect } from "react";
import { Redirect, Route, useLocation } from "react-router-dom";
/*
Private route - React Component, user can only react the desired route if they have login
*/
const PrivateRoute = ({ redirectPath, component: Component, ...rest }) => {
  const [isLoggedIn, setIsLoggedIn] = useState(
    JSON.parse(localStorage.getItem("profile")) != null ? true : false
  );
  const location = useLocation();

  useEffect(() => {
    setIsLoggedIn(
      JSON.parse(localStorage.getItem("profile")) != null ? true : false
    );
  }, [location]);

  return (
    <Route
      {...rest}
      render={(props) =>
        isLoggedIn ? (
          <Component {...props} />
        ) : (
          <Redirect
            to={{ pathname: redirectPath, state: { from: props.location } }}
          />
        )
      }
    />
  );
};

/*
Route Redirect - React Component, redirect route to a provided route.
*/
const RouteRedirect = ({ redirectPath, path, ...rest }) => {
  const [isLoggedIn, setIsLoggedIn] = useState(
    JSON.parse(localStorage.getItem("profile")) != null ? true : false
  );
  const location = useLocation();

  useEffect(() => {
    setIsLoggedIn(
      JSON.parse(localStorage.getItem("profile")) != null ? true : false
    );
  }, [location]);
  return (
    <Route
      {...rest}
      render={(props) =>
        isLoggedIn ? (
          <Redirect
            to={{ pathname: redirectPath, state: { from: props.location } }}
          />
        ) : (
          <Redirect
            to={{ pathname: redirectPath, state: { from: props.location } }}
          />
        )
      }
    />
  );
};

/*
Public route - React Component, user can only react the desired route if they have not login
*/
const PublicRoute = ({ redirectPath, component: Component, ...rest }) => {
  // Add your own authentication on the below line.
  const [isLoggedIn, setIsLoggedIn] = useState(
    JSON.parse(localStorage.getItem("profile")) != null ? true : false
  );
  const location = useLocation();

  useEffect(() => {
    setIsLoggedIn(
      JSON.parse(localStorage.getItem("profile")) != null ? true : false
    );
  }, [location]);

  return (
    <Route
      {...rest}
      render={(props) =>
        !isLoggedIn ? (
          <Component {...props} />
        ) : (
          <Redirect
            to={{ pathname: redirectPath, state: { from: props.location } }}
          />
        )
      }
    />
  );
};

export default PrivateRoute;
export { RouteRedirect, PublicRoute };
