import React, { useState, useEffect } from "react";
import { useSelector } from "react-redux";
import { Link } from "react-router-dom";
import AccessTimeRoundedIcon from "@material-ui/icons/AccessTimeRounded";
import EventRoundedIcon from "@material-ui/icons/EventRounded";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import IconButton from "@material-ui/core/IconButton";
import RepeatRoundedIcon from "@material-ui/icons/RepeatRounded";
import { RRule } from "rrule";
import moment from "moment";
import { startOfWeek, endOfWeek } from "date-fns";
import clsx from "clsx";
import {
  Card,
  Grid,
  Typography,
  CardMedia,
  Paper,
  List,
  ListItem,
  Divider,
  ListItemText,
  Box,
  CardActions,
  Collapse,
  ListItemAvatar,
  Avatar,
  Tooltip,
  Zoom,
} from "@material-ui/core";
import useStyles from "./Styles";
import ActiveNotifications from "../../images/ActiveNotifications.png";
import TodayEvent from "../../images/TodayEvent.png";
import UpcomingExamsAndTests from "../../images/UpcomingExamsAndTests.png";
import UpcomingEvents from "../../images/UpcomingEvents.png";

const DATE_FORMAT = "DD MMMM YYYY, dddd";
const TIME_FORMAT = "HH:mm";
const DATE_TIME_FORMAT = "DD MMM, HH:mm";
const CARDS_ELEVATION = 9;

/*
Home Page - React Component
*/
const Home = () => {
  const classes = useStyles();

  //get user start of the week form the user settings.
  const [startOfTheWeek] = useState(
    JSON.parse(localStorage.getItem("settings"))?.weekStartDay.index
  );
  const [expandedTestsExams, setExpandedTestsExams] = React.useState(false);
  const [expandedTodayEvents, setExpandedTodayEvents] = React.useState(false);
  const [expandedNotification, setxpandedNotification] = React.useState(false);
  const [expandedThisWeekEvents, setExpandedThisWeekEvents] = React.useState(false);
  const [events, setEvents] = useState(useSelector((state) => state.events));

   // get notifications
  const [notifications, setNotifications] = useState(
    JSON.parse(localStorage.getItem("notifications"))
      ?.sort(function (a, b) {
        var dateA = new Date(a.dateSent),
          dateB = new Date(b.dateSent);
        return dateB - dateA;
      })
      ?.filter((notification) => new Date(notification.dateSent) <= new Date())
  );

  //get active notifications
  const [activeNotifications, setActiveNotifications] = useState(
    notifications?.filter((notification) => notification.isNotActive === false)
  );

  // get today events 
  const [todaysEvents, setTodaysEvents] = useState(
    events?.filter(
      (event) =>
        (new Date(event.startDate) <= new Date() &&
          new Date(event.endDate) >= new Date()) ||
        rRuleFallsToday(event) ||
        new Date(event.startDate).toDateString() ===
          new Date().toDateString() ||
        new Date(event.endDate).toDateString() === new Date().toDateString()
    )
  );

   // get test and exams
  const [testsAndExams, setTestsAndExams] = useState(
    events
      ?.filter(
        (event) =>
          (event.typeId === 1 || event.typeId === 2) &&
          (new Date(event.startDate) >= new Date() ||
            (new Date(event.startDate) <= new Date() &&
              new Date(event.endDate) >= new Date()))
      )
      ?.sort(function (a, b) {
        var dateA = new Date(a.startDate),
          dateB = new Date(b.startDate);
        return dateA - dateB;
      })
  );

  // get this weeks events
  const [thisWeekEvents, setThisWeekEvents] = useState(
    events
      ?.filter(
        (event) =>
          (startOfWeek(new Date(), {
            weekStartsOn: startOfTheWeek ? startOfTheWeek : 0,
          }) <= new Date(event.startDate) &&
            new Date(event.startDate) <=
              endOfWeek(new Date(), {
                weekStartsOn: startOfTheWeek ? startOfTheWeek : 0,
              })) ||
          rRuleFallsThisWeek(event)
      )
      ?.sort(function (a, b) {
        var dateA = new Date(a.startDate),
          dateB = new Date(b.startDate);
        return dateA - dateB;
      })
  );

  // Methods to handle expanding all the cards in the page
  const handleExpandClickTestExams = () => {
    setExpandedTestsExams(!expandedTestsExams);
  };
  const handleExpandClickThisWeekEvents = () => {
    setExpandedThisWeekEvents(!expandedThisWeekEvents);
  };
  const handleExpandClickTodayEvents = () => {
    setExpandedTodayEvents(!expandedTodayEvents);
  };
  const handleExpandNotification = () => {
    setxpandedNotification(!expandedNotification);
  };

  //get active notifications
  useEffect(() => {
    setActiveNotifications(
      notifications?.filter(
        (notification) => notification.isNotActive === false
      )
    );
  }, [notifications]);


  useEffect(() => {
     // get today events 
    setTodaysEvents(
      events?.filter(
        (event) =>
          (new Date(event.startDate) <= new Date() &&
            new Date(event.endDate) >= new Date()) ||
          rRuleFallsToday(event) ||
          new Date(event.startDate).toDateString() ===
            new Date().toDateString() ||
          new Date(event.endDate).toDateString() === new Date().toDateString()
      )
    );
    // get test and exams
    setTestsAndExams(
      events
        ?.filter(
          (event) =>
            (event.typeId === 1 || event.typeId === 2) &&
            (new Date(event.startDate) >= new Date() ||
              (new Date(event.startDate) <= new Date() &&
                new Date(event.endDate) >= new Date()))
        )
        ?.sort(function (a, b) {
          var dateA = new Date(a.startDate),
            dateB = new Date(b.startDate);
          return dateA - dateB;
        })
    );
    // get this weeks events
    setThisWeekEvents(
      events
        ?.filter(
          (event) =>
            (startOfWeek(new Date(), {
              weekStartsOn: startOfTheWeek ? startOfTheWeek : 0,
            }) <= new Date(event.startDate) &&
              new Date(event.startDate) <=
                endOfWeek(new Date(), {
                  weekStartsOn: startOfTheWeek ? startOfTheWeek : 0,
                })) ||
            rRuleFallsThisWeek(event)
        )
        ?.sort(function (a, b) {
          var dateA = new Date(a.startDate),
            dateB = new Date(b.startDate);
          return dateA - dateB;
        })
    );
    // eslint-disable-next-line
  }, [events]);

  // Event lister
  document.addEventListener("DOMContentLoaded", function () {
    getData();
  });

  // Method to get events and notifications
  function getData() {
    getEvents();
    getNotifications();
  }

  function getEvents() {
    setEvents(JSON.parse(localStorage.getItem("events")));
  }

  function getNotifications() {
    setNotifications(
      JSON.parse(localStorage.getItem("notifications"))
        ?.sort(function (a, b) {
          var dateA = new Date(a.dateSent),
            dateB = new Date(b.dateSent);
          return dateB - dateA;
        })
        ?.filter(
          (notification) => new Date(notification.dateSent) <= new Date()
        )
    );
  }

  //Method to check if the rRule fall within the current week
  function rRuleFallsThisWeek(event) {
    let result = false;
    event.rRule
      ? (result =
          RRule.fromString(event.rRule).between(
            new Date(
              startOfWeek(new Date(), {
                weekStartsOn: startOfTheWeek ? startOfTheWeek : 0,
              }).setDate(
                startOfWeek(new Date(), {
                  weekStartsOn: startOfTheWeek ? startOfTheWeek : 0,
                }).getDate() - 1
              )
            ),
            new Date(
              endOfWeek(new Date(), {
                weekStartsOn: startOfTheWeek ? startOfTheWeek : 0,
              }).setDate(
                endOfWeek(new Date(), {
                  weekStartsOn: startOfTheWeek ? startOfTheWeek : 0,
                }).getDate() + 1
              )
            )
          ).length > 0)
      : (result = false);

    return result;
  }

  //Method to check if the rRule fall today
  function rRuleFallsToday(event) {
    let result = false;
    event.rRule
      ? (result =
          RRule.fromString(event.rRule)
            .all()
            ?.filter(
              (e) => new Date(e).toDateString() === new Date().toDateString()
            ).length > 0)
      : (result = false);

    return result;
  }

  return (
    // Grid, Contain all the cards on the home page.
    <Grid
      container
      direction="row"
      justifyContent="center"
      alignItems="center"
      onClick={getData}
    >
      <Grid item xs={12} md={6} xl={3} className={classes.grid}>
        {/*Todays Events - Card */}
        <Card className={classes.card} elevation={CARDS_ELEVATION}>
          <Box component={Link} to={"/User/Scheduler"}>
            <CardMedia
              component="img"
              alt="Todays Events"
              height="395"
              image={TodayEvent}
              title="Todays Events"
            />
          </Box>
          <CardActions disableSpacing className={classes.collapseButton}>
            <Typography gutterBottom variant="h5" component="h2">
              Todays Events
            </Typography>
            <ListItemAvatar>
              <Avatar>
                <IconButton
                  className={clsx(classes.expand, {
                    [classes.expandOpen]: expandedTodayEvents,
                  })}
                  onClick={handleExpandClickTodayEvents}
                  aria-expanded={expandedTodayEvents}
                  aria-label="show more"
                >
                  <ExpandMoreIcon />
                </IconButton>
              </Avatar>
            </ListItemAvatar>
          </CardActions>
          <Collapse in={expandedTodayEvents} timeout="auto" unmountOnExit>
            <Grid container spacing={1}>
              {todaysEvents === undefined ||
              todaysEvents?.length === 0 ||
              todaysEvents === [] ? (
                <Grid item xs={12}>
                  <Paper className={classes.events}>
                    <List>
                      <ListItemText>You have no events.</ListItemText>
                    </List>
                  </Paper>
                </Grid>
              ) : null}
              {todaysEvents?.map((event, index) => {
                return (
                  <Grid item xs={12} key={index}>
                    <Paper className={classes.events}>
                      <List>
                        <ListItemText> {event.title} </ListItemText>
                        <Divider />
                        <ListItem>
                          <EventRoundedIcon />
                          <Box className={classes.listItemText}>
                            {event.rRule ||
                            new Date(event.startDate).toDateString() !==
                              new Date(event.endDate).toDateString()
                              ? moment(new Date()).format(DATE_FORMAT)
                              : moment(event.startDate).format(DATE_FORMAT)}
                          </Box>
                        </ListItem>
                        <ListItem>
                          <AccessTimeRoundedIcon />
                          <Box className={classes.listItemText}>
                            {new Date(event.startDate).toDateString() ===
                            new Date(event.endDate).toDateString()
                              ? moment(event.startDate).format(TIME_FORMAT)
                              : moment(event.startDate).format(
                                  DATE_TIME_FORMAT
                                )}
                            {" - "}
                            {new Date(event.startDate).toDateString() ===
                            new Date(event.endDate).toDateString()
                              ? moment(event.endDate).format(TIME_FORMAT)
                              : moment(event.endDate).format(DATE_TIME_FORMAT)}
                          </Box>
                        </ListItem>
                      </List>
                    </Paper>
                  </Grid>
                );
              })}
            </Grid>
          </Collapse>
        </Card>
      </Grid>
      <Grid item xs={12} md={6} xl={3} className={classes.grid}>
        {/*This Week Events - Card */}
        <Card className={classes.card} elevation={CARDS_ELEVATION}>
          <Box component={Link} to={"/User/Scheduler"}>
            <CardMedia
              component="img"
              alt="This Week Events"
              height="395"
              image={UpcomingEvents}
              title="This Week Events"
            />
          </Box>
          <CardActions disableSpacing className={classes.collapseButton}>
            <Typography gutterBottom variant="h5" component="h2">
              This Week Events
            </Typography>
            <ListItemAvatar>
              <Avatar>
                <IconButton
                  className={clsx(classes.expand, {
                    [classes.expandOpen]: expandedThisWeekEvents,
                  })}
                  onClick={handleExpandClickThisWeekEvents}
                  aria-expanded={expandedThisWeekEvents}
                  aria-label="show more"
                >
                  <ExpandMoreIcon />
                </IconButton>
              </Avatar>
            </ListItemAvatar>
          </CardActions>
          <Collapse in={expandedThisWeekEvents} timeout="auto" unmountOnExit>
            <Grid container spacing={1}>
              {thisWeekEvents === undefined ||
              thisWeekEvents?.length === 0 ||
              thisWeekEvents === [] ? (
                <Grid item xs={12}>
                  <Paper className={classes.events}>
                    <List>
                      <ListItemText>
                        You have no events for this week.
                      </ListItemText>
                    </List>
                  </Paper>
                </Grid>
              ) : null}
              {thisWeekEvents?.map((event) => {
                return (
                  <Grid item xs={12}>
                    <Paper
                      className={
                        event.rRule ? classes.eventsRepeat : classes.events
                      }
                    >
                      <List>
                        <ListItemText>{event.title}</ListItemText>
                        <Divider />
                        <ListItem>
                          {event.rRule ? (
                            <RepeatRoundedIcon />
                          ) : (
                            <EventRoundedIcon />
                          )}
                          <Box className={classes.listItemText}>
                            {event.rRule
                              ? "This is a repeating event"
                              : moment(event.startDate).format(DATE_FORMAT)}
                          </Box>
                        </ListItem>
                        <ListItem>
                          <AccessTimeRoundedIcon />
                          <Box className={classes.listItemText}>
                            {new Date(event.startDate).toDateString() ===
                            new Date(event.endDate).toDateString()
                              ? moment(event.startDate).format(TIME_FORMAT)
                              : moment(event.startDate).format(
                                  DATE_TIME_FORMAT
                                )}
                            {" - "}
                            {new Date(event.startDate).toDateString() ===
                            new Date(event.endDate).toDateString()
                              ? moment(event.endDate).format(TIME_FORMAT)
                              : moment(event.endDate).format(DATE_TIME_FORMAT)}
                          </Box>
                        </ListItem>
                      </List>
                    </Paper>
                  </Grid>
                );
              })}
            </Grid>
          </Collapse>
        </Card>
      </Grid>
      <Grid item xs={12} md={6} xl={3} className={classes.grid}>
         {/*Active Notifications - Card */}
        <Card className={classes.card} elevation={CARDS_ELEVATION}>
          <Box component={Link} to={"/User/Notifications"}>
            <CardMedia
              component="img"
              alt="Active Notifications"
              height="395"
              image={ActiveNotifications}
              title="Active Notifications"
            />
          </Box>
          <CardActions disableSpacing className={classes.collapseButton}>
            <Typography gutterBottom variant="h5" component="h2">
              Active Notifications
            </Typography>
            <ListItemAvatar>
              <Avatar>
                <IconButton
                  className={clsx(classes.expand, {
                    [classes.expandOpen]: expandedNotification,
                  })}
                  onClick={handleExpandNotification}
                  aria-expanded={expandedNotification}
                  aria-label="show more"
                >
                  <ExpandMoreIcon />
                </IconButton>
              </Avatar>
            </ListItemAvatar>
          </CardActions>
          <Collapse in={expandedNotification} timeout="auto" unmountOnExit>
            <Grid container spacing={1}>
              {activeNotifications === undefined ||
              activeNotifications?.length === 0 ||
              activeNotifications === [] ? (
                <Grid item xs={12}>
                  <Paper className={classes.events}>
                    <List>
                      <ListItemText>
                        You have no active notifications.
                      </ListItemText>
                    </List>
                  </Paper>
                </Grid>
              ) : null}
              {activeNotifications?.map((notification) => {
                return (
                  <Grid item xs={12}>
                    <Paper className={classes.events}>
                      <List>
                        <ListItemText>{notification.heading}</ListItemText>
                        <Divider />

                        <ListItem>
                          <EventRoundedIcon />
                          <Tooltip
                            title="Date Sent"
                            placement="right"
                            TransitionComponent={Zoom}
                          >
                            <Box className={classes.listItemText}>
                              {moment(notification.dateSent).format(
                                DATE_FORMAT
                              )}
                            </Box>
                          </Tooltip>
                        </ListItem>
                      </List>
                    </Paper>
                  </Grid>
                );
              })}
            </Grid>
          </Collapse>
        </Card>
      </Grid>
      <Grid item xs={12} md={6} xl={3} className={classes.grid}>
        {/*Upcoming Tests And Exams - Card */}
        <Card className={classes.card} elevation={CARDS_ELEVATION}>
          <Box component={Link} to={"/User/Scheduler"}>
            <CardMedia
              component="img"
              alt="Upcoming Tests And Exams"
              height="395"
              image={UpcomingExamsAndTests}
              title="Upcoming Tests And Exams"
            />
          </Box>
          <CardActions disableSpacing className={classes.collapseButton}>
            <Typography gutterBottom variant="h5" component="h2">
              Upcoming Tests And Exams
            </Typography>
            <ListItemAvatar>
              <Avatar>
                <IconButton
                  className={clsx(classes.expand, {
                    [classes.expandOpen]: expandedTestsExams,
                  })}
                  onClick={handleExpandClickTestExams}
                  aria-expanded={expandedTestsExams}
                  aria-label="show more"
                >
                  <ExpandMoreIcon />
                </IconButton>
              </Avatar>
            </ListItemAvatar>
          </CardActions>
          <Collapse in={expandedTestsExams} timeout="auto" unmountOnExit>
            <Grid container spacing={1}>
              {testsAndExams === undefined ||
              testsAndExams?.length === 0 ||
              testsAndExams === [] ? (
                <Grid item xs={12}>
                  <Paper className={classes.events}>
                    <List>
                      <ListItemText>You have no tests or exams.</ListItemText>
                    </List>
                  </Paper>
                </Grid>
              ) : null}
              {testsAndExams?.map((event) => {
                return (
                  <Grid item xs={12}>
                    <Paper
                      className={
                        event.typeId === 2
                          ? classes.eventsTest
                          : classes.eventsExam
                      }
                    >
                      <List>
                        <ListItemText>{event.title}</ListItemText>
                        <Divider />
                        <ListItem>
                          <EventRoundedIcon />
                          <Box className={classes.listItemText}>
                            {moment(event.startDate).format(DATE_FORMAT)}
                          </Box>
                        </ListItem>
                        <ListItem>
                          <AccessTimeRoundedIcon />
                          <Box className={classes.listItemText}>
                            {new Date(event.startDate).toDateString() ===
                            new Date(event.endDate).toDateString()
                              ? moment(event.startDate).format(TIME_FORMAT)
                              : moment(event.startDate).format(
                                  DATE_TIME_FORMAT
                                )}
                            {" - "}
                            {new Date(event.startDate).toDateString() ===
                            new Date(event.endDate).toDateString()
                              ? moment(event.endDate).format(TIME_FORMAT)
                              : moment(event.endDate).format(DATE_TIME_FORMAT)}
                          </Box>
                        </ListItem>
                      </List>
                    </Paper>
                  </Grid>
                );
              })}
            </Grid>
          </Collapse>
        </Card>
      </Grid>
    </Grid>
  );
};

export default Home;
