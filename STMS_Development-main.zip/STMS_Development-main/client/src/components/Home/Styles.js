import { makeStyles } from "@material-ui/core/styles";

// Material UI Styles
const useStyles = makeStyles((theme) => ({
  events: {
    paddingLeft: theme.spacing(2),
    textAlign: "left",
    background: "#1377AC",
  },
  eventsRepeat: {
    paddingLeft: theme.spacing(2),
    textAlign: "left",
    background: "#009688",
  },
  eventsExam: {
    paddingLeft: theme.spacing(2),
    textAlign: "left",
    background: "#4caf50",
  },
  eventsTest: {
    paddingLeft: theme.spacing(2),
    textAlign: "left",
    background: "#00bcd4",
  },
  listItemText: {
    paddingLeft: "10px",
    fontSize: theme.typography.pxToRem(15),
  },
  collapseButton: {
    justifyContent: "space-between",
    paddingRight: "0px",
  },
  card: {
    maxWidth: 420,
    minWidth: 400,
    minHeight: 450,
    padding: theme.spacing(2),
  },
  grid: {
    maxWidth: 420,
    minWidth: 400,
    minHeight: 450,
    paddingBottom: theme.spacing(2),
    [theme.breakpoints.up("sm")]: {
      paddingRight: theme.spacing(2),
    },
  },
  expand: {
    transform: "rotate(0deg)",
    marginLeft: "auto",
    transition: theme.transitions.create("transform", {
      duration: theme.transitions.duration.shortest,
    }),
  },
  expandOpen: {
    transform: "rotate(180deg)",
  },
}));

export default useStyles;
