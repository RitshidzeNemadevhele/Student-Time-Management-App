import React, { useState, useEffect } from "react";
import { useSelector } from "react-redux";
import FormatListNumberedRoundedIcon from "@material-ui/icons/FormatListNumberedRounded";
import MoreVertRoundedIcon from "@material-ui/icons/MoreVertRounded";
import MenuRoundedIcon from "@material-ui/icons/MenuRounded";
import NotificationsRoundedIcon from "@material-ui/icons/NotificationsRounded";
import EventAvailableRoundedIcon from "@material-ui/icons/EventAvailableRounded";
import HomeRoundedIcon from "@material-ui/icons/HomeRounded";
import CloseRoundedIcon from "@material-ui/icons/CloseRounded";
import ExitToAppRoundedIcon from "@material-ui/icons/ExitToAppRounded";
import SettingsRoundedIcon from "@mui/icons-material/SettingsRounded";
import { Link, useLocation } from "react-router-dom";
import {
  Avatar,
  ListItemIcon,
  List,
  ListItemText,
  Toolbar,
  ListItem,
  Menu,
  MenuItem,
  Badge,
  Typography,
  IconButton,
  Hidden,
  Drawer,
  Divider,
  CssBaseline,
  AppBar,
} from "@material-ui/core";
import { useTheme } from "@material-ui/core/styles";
import useStyles from "./Style";
import { createTheme, Paper, ThemeProvider } from "@material-ui/core";
import { Box } from "@mui/system";
import logo from "../../images/logo.png";

/*
Narvigation Bar - React Component
*/
const ResponsiveDrawer = ({ user, logOut, componentToRender, PageTitle }) => {
    //Create Dark Theme
  const darkTheme = createTheme({
    palette: {
      type: "dark",
    },
  });

  const classes = useStyles();
  const theme = useTheme();
  const [mobileOpen, setMobileOpen] = React.useState(false);
  const [anchorEl, setAnchorEl] = React.useState(null);
  const [mobileMoreAnchorEl, setMobileMoreAnchorEl] = React.useState(null);
  const [notifications, setNotifications] = useState(
    useSelector((state) => state.notifications)
  );

  // get number of active notifications
  const [numberOfNotifications, setNumberOfNotifications] = useState(
    notifications?.filter(
      (notification) =>
        notification.isNotActive === false &&
        new Date(notification.dateSent) <= new Date()
    ).length
  );

  const location = useLocation();

  // Event lister
  document.addEventListener("DOMContentLoaded", function () {
    getNumberOfNotifications();
  });

  // get number of active notifications
  useEffect(() => {
    setNumberOfNotifications(
      notifications?.filter(
        (notification) =>
          notification.isNotActive === false &&
          new Date(notification.dateSent) <= new Date()
      ).length
    );
  }, [notifications, numberOfNotifications]);

  // Method to get user notification
  function getNumberOfNotifications() {
    setNotifications(JSON.parse(localStorage.getItem("notifications")));
  }

  var drawerIcons = [
    <HomeRoundedIcon />,
    <EventAvailableRoundedIcon />,
    <FormatListNumberedRoundedIcon />,
    <NotificationsRoundedIcon />,
    <SettingsRoundedIcon />,
    <ExitToAppRoundedIcon />,
  ];

  var drawerText = [
    "Home",
    "Scheduler",
    "To-do List",
    "Notifications",
    "Settings",
    "Log Out",
  ];

  var drawerButtonsActions = [
    "/Home",
    "/User/Scheduler",
    "/User/TodoList",
    "/User/Notifications",
    "/User/Settings",
    handleLogoutClick,
  ];

  const isMenuOpen = Boolean(anchorEl);
  const isMobileMenuOpen = Boolean(mobileMoreAnchorEl);

  function handleLogoutClick() {
    logOut();
  }

  function handleDrawerToggle() {
    setMobileOpen(!mobileOpen);
  }
  const handleProfileMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMobileMenuClose = () => {
    setMobileMoreAnchorEl(null);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
    handleMobileMenuClose();
  };

  const handleMobileMenuOpen = (event) => {
    setMobileMoreAnchorEl(event.currentTarget);
  };

  const menuId = "primary-search-account-menu";
  // Method to render the menu
  const renderMenu = (
    <Menu
      anchorEl={anchorEl}
      anchorOrigin={{ vertical: "top", horizontal: "right" }}
      id={menuId}
      keepMounted
      transformOrigin={{ vertical: "top", horizontal: "right" }}
      open={isMenuOpen}
      onClose={handleMenuClose}
    >
      <List>
        <ListItem>
          <ListItemIcon>
            <Avatar
              className="avatar"
              alt={user?.profile?.name}
              src={user?.profile?.imageUrl}
            >
              {user?.profile?.name.charAt(0)}
            </Avatar>
          </ListItemIcon>
          <Typography>
            {user?.profile?.name}
            <Typography className={classes.email}>
              {user?.profile?.email}
            </Typography>
          </Typography>
        </ListItem>
      </List>
      <Divider />
      <MenuItem
        onClick={handleMenuClose}
        component={Link}
        to={"/User/Settings"}
      >
        <SettingsRoundedIcon className={classes.menuIcon} />
        Settings
      </MenuItem>
      <MenuItem onClick={handleLogoutClick}>
        <ExitToAppRoundedIcon className={classes.menuIcon} />
        Log Out
      </MenuItem>
    </Menu>
  );

  const mobileMenuId = "primary-search-account-menu-mobile";

  // Method to render the mobile menu
  const renderMobileMenu = (
    <Menu
      anchorEl={mobileMoreAnchorEl}
      anchorOrigin={{ vertical: "top", horizontal: "right" }}
      id={mobileMenuId}
      keepMounted
      transformOrigin={{ vertical: "top", horizontal: "right" }}
      open={isMobileMenuOpen}
      onClose={handleMobileMenuClose}
    >
      <MenuItem component={Link} to={"/User/Notifications"}>
        <IconButton aria-label="show 11 new notifications" color="inherit">
          <Badge badgeContent={numberOfNotifications} color="secondary">
            <NotificationsRoundedIcon />
          </Badge>
        </IconButton>
        <Typography>Notifications</Typography>
      </MenuItem>
      <MenuItem onClick={handleProfileMenuOpen}>
        <IconButton
          aria-label="account of current user"
          aria-controls="primary-search-account-menu"
          aria-haspopup="true"
          color="inherit"
        >
          <Avatar
            className="avatar"
            alt={user?.profile?.name}
            src={user?.profile?.imageUrl}
          >
            {user?.profile?.name.charAt(0)}
          </Avatar>
        </IconButton>
        <Typography>{user?.profile?.name}</Typography>
      </MenuItem>
    </Menu>
  );

  // Method to render the drawer
  const drawer = (
    <div>
      <Divider />
      <List>
        {drawerText?.map((text, index) => (
          <Box>
            <ListItem
              button
              key={index}
              component={Link}
              onClick={text === "Log Out" ? drawerButtonsActions[index] : null}
              className={
                location.pathname.includes(text)
                  ? classes.clickedDrawerItem
                  : location.pathname.includes("/") &&
                    !location.pathname.includes("User") &&
                    text === "Home"
                  ? classes.clickedDrawerItem
                  : location.pathname.includes("TodoList") &&
                    text === "To-do List"
                  ? classes.clickedDrawerItem
                  : null
              }
              to={
                text !== "Log Out" ? drawerButtonsActions[index] : "/User/Login"
              }
            >
              <ListItemIcon>{drawerIcons[index]}</ListItemIcon>
              <ListItemText primary={text} />
            </ListItem>
            <Divider />
          </Box>
        ))}
      </List>
    </div>
  );

  return (
    <ThemeProvider theme={darkTheme}>
      <Paper className={classes.grow}>
        <CssBaseline />
        <AppBar position="fixed" className={classes.appBar}>
          <Toolbar>
            <IconButton
              color="inherit"
              aria-label="Open drawer"
              edge="start"
              onClick={handleDrawerToggle}
              className={classes.menuButton}
            >
              <MenuRoundedIcon />
            </IconButton>
            <Box component={Link} to={"/Home"}>
              <img src={logo} alt={"Logo"} width="60" height="60" />
            </Box>

            <Typography className={classes.appName} variant="h6" noWrap >
              Student Time Management System
            </Typography>
            <div className={classes.grow} />
            <div className={classes.sectionDesktop}>
              <IconButton
                aria-label="show new notifications"
                color="inherit"
                component={Link}
                to={"/User/Notifications"}
              >
                <Badge badgeContent={numberOfNotifications} color="secondary">
                  <NotificationsRoundedIcon />
                </Badge>
              </IconButton>
              <IconButton
                edge="end"
                aria-label="account of current user"
                aria-controls={menuId}
                aria-haspopup="true"
                onClick={handleProfileMenuOpen}
                color="inherit"
              >
                <Avatar
                  className="avatar"
                  alt={user?.profile?.name}
                  src={user?.profile?.imageUrl}
                >
                  {user?.profile?.name.charAt(0)}
                </Avatar>
              </IconButton>
              <Typography
                className={classes.userName}
                onClick={handleProfileMenuOpen}
              >
                {user?.profile?.name}
              </Typography>
            </div>
            <div className={classes.sectionMobile}>
              <IconButton
                aria-label="show more"
                aria-controls={mobileMenuId}
                aria-haspopup="true"
                onClick={handleMobileMenuOpen}
                color="inherit"
              >
                <MoreVertRoundedIcon />
              </IconButton>
            </div>
          </Toolbar>
        </AppBar>
        {renderMobileMenu}
        {renderMenu}
        <nav className={classes.drawer}>
          {/* The implementation can be swapped with js to avoid SEO duplication of links. */}
          <Hidden smUp implementation="css">
            <Drawer
              variant="temporary"
              anchor={theme.direction === "rtl" ? "right" : "left"}
              open={mobileOpen}
              onClose={handleDrawerToggle}
              classes={{
                paper: classes.drawerPaper,
              }}
              ModalProps={{
                keepMounted: true, // Better open performance on mobile.
              }}
            >
              <IconButton
                onClick={handleDrawerToggle}
                className={classes.closeMenuButton}
              >
                <CloseRoundedIcon />
              </IconButton>
              {drawer}
            </Drawer>
          </Hidden>
          <Hidden xsDown implementation="css">
            <Drawer
              className={classes.drawer}
              variant="permanent"
              classes={{
                paper: classes.drawerPaper,
              }}
            >
              <div className={classes.toolbar} />
              {drawer}
            </Drawer>
          </Hidden>
        </nav>
        <div
          id="content"
          className={classes.content}
          onClick={getNumberOfNotifications}
        >
          <div className={classes.toolbar} />
          {PageTitle}
          {componentToRender}
        </div>
      </Paper>
    </ThemeProvider>
  );
};

export default ResponsiveDrawer;
