import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import { Typography } from "@material-ui/core";

const useStyles = makeStyles((theme) => ({
  badge: {
    marginLeft: "15px",
    marginRight: "15px",
  },
  pageTitle: {
    display: "flex",
    flexDirection: "row",
    justifyContent: "center",
    margin: "1% 0% 1% 0%",
  },
}));
/*
Page Title - React Component
*/
export default function PageTitle({ Icon, Title }) {
  const classes = useStyles();
  return (
    <div>
      <Typography className={classes.pageTitle} variant="h6" noWrap>
        <div className={classes.badge}>{Icon} </div> {Title}
        <div className={classes.badge}>{Icon} </div>
      </Typography>
    </div>
  );
}
