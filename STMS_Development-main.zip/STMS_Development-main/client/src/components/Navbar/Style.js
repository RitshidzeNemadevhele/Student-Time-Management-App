import { makeStyles } from "@material-ui/core/styles";
const drawerWidth = 200;

// Material UI Styles
const useStyles = makeStyles((theme) => ({
  listItem: {
    backgroundColor: theme.palette.background.paper,
  },
  email: {
    fontSize: theme.typography.pxToRem(14),
  },
  appName: {
    marginLeft: "7px",
  },
  menuIcon: {
    marginRight: "5px",
    cursor: "pointer",
  },
  clickedDrawerItem: {
    "&:hover": {
      backgroundColor: "#0F5F8A",
    },
    backgroundColor: "#0F5F8A",
  },
  userName: {
    padding: theme.spacing(3, 2),
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    cursor: "pointer",
  },
  grow: {
    flexGrow: 1,
    display: "flex",
  },
  drawer: {
    [theme.breakpoints.up("sm")]: {
      width: drawerWidth,
      flexShrink: 0,
    },
  },
  appBar: {
    zIndex: theme.zIndex.drawer + 1,
    background: "#0F5F8A",
  },
  menuButton: {
    marginRight: theme.spacing(2),
    [theme.breakpoints.up("sm")]: {
      display: "none",
    },
  },
  toolbar: theme.mixins.toolbar,
  drawerPaper: {
    width: drawerWidth,
  },
  content: {
    flexGrow: 1,
    padding: theme.spacing(1),
    zIndex: theme.zIndex.drawer - 1,
    height: "auto",
    minHeight: "100vh",
  },
  closeMenuButton: {
    marginRight: "auto",
    marginLeft: "0",
    marginTop: "4.5px",
    marginBottom: "4.5px",
  },
  sectionDesktop: {
    display: "none",
    [theme.breakpoints.up("md")]: {
      display: "flex",
    },
  },
  sectionMobile: {
    display: "flex",
    [theme.breakpoints.up("md")]: {
      display: "none",
    },
  },
  title: {
    display: "none",
    [theme.breakpoints.up("sm")]: {
      display: "block",
    },
  },
  logOutBtn: {
    flexGrow: 1,
    display: "flex",
  },
}));

export default useStyles;
