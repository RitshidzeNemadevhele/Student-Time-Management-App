import React from "react";
import { useDispatch } from "react-redux";
import Accordion from "@material-ui/core/Accordion";
import AccordionDetails from "@material-ui/core/AccordionDetails";
import AccordionSummary from "@material-ui/core/AccordionSummary";
import Typography from "@material-ui/core/Typography";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import Badge from "@material-ui/core/Badge";
import NotificationsActiveRoundedIcon from "@material-ui/icons/NotificationsActiveRounded";
import NotificationsActiveOutlinedIcon from "@mui/icons-material/NotificationsActiveOutlined";
import { Grid } from "@material-ui/core";
import useStyles from "./Styles";
import { changeNotification } from "../../actions/notifications";

const ACCORDION_ELEVATION = 9;
/*
Notification - React Component
*/
export default function Notification({ Notifications }) {
  const classes = useStyles();
  const [expanded, setExpanded] = React.useState(false);
  const dispatch = useDispatch();

  //Method to handle opening and closing of the notifications
  const handleChange = (panel) => (event, isExpanded) => {
    setExpanded(isExpanded ? panel : false);
    Notifications.forEach((notification) => {
      if (notification.id === panel && !notification.isNotActive) {
        notification.isNotActive = true;
        dispatch(changeNotification(notification));
      }
    });
  };

  return (
    <div className={classes.root}>
      <Typography className={classes.pageTitle} variant="h6" noWrap>
        <NotificationsActiveOutlinedIcon className={classes.badge} />
        Notifications
        <NotificationsActiveOutlinedIcon className={classes.badge} />
      </Typography>
      {Notifications === undefined ||
      Notifications?.length === 0 ||
      Notifications === [] ? (
        <Typography className={classes.info} noWrap>
          You currently have no notifications.
        </Typography>
      ) : null}
      <Grid container spacing={1}>
        {Notifications?.map((notification, index) => {
          return (
            <Grid item xs={12} md={6} lg={4} xl={3} key={index}>
              {/*Notication - Accordion */}
              <Accordion
                className={classes.notification}
                expanded={expanded === notification.id}
                onChange={handleChange(notification.id)}
                elevation={ACCORDION_ELEVATION}
              >
                <AccordionSummary
                  expandIcon={<ExpandMoreIcon />}
                  aria-controls="panel1bh-content"
                  id="panel1bh-header"
                >
                  <Typography className={classes.heading}>
                    {notification.heading}
                  </Typography>
                  <Typography className={classes.secondaryHeading}>
                    {notification.secondaryHeading}
                    <Badge
                      className={classes.badge}
                      color="secondary"
                      variant="dot"
                      invisible={notification.isNotActive}
                    >
                      <NotificationsActiveRoundedIcon />
                    </Badge>
                  </Typography>
                </AccordionSummary>
                <AccordionDetails>
                  <Typography>{notification.notification}</Typography>
                </AccordionDetails>
              </Accordion>
            </Grid>
          );
        })}
      </Grid>
    </div>
  );
}
