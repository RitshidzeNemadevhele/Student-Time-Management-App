import { useState } from "react";
import { useDispatch } from "react-redux";
import moment from "moment";
import { createNotification } from "../../actions/notifications";

const SENTENCE_DATE_FORMAT = "Do of MMMM, ddd";
const SENT_DATE_FORMAT = "DD MMM YYYY, ddd";

const REM_30_DAYS = 30;
const REM_10_DAYS = 10;
const REM_7_DAYS = 7;
const REM_5_DAYS = 5;

// Automatically generate user notifications based on their entered events
export function CreateNotificationsAI() {
  const [user] = useState(JSON.parse(localStorage.getItem("profile")));
  const [events] = useState(JSON.parse(localStorage.getItem("events")));

  const dispatch = useDispatch();

  if (events !== undefined) {
    events.forEach((event) => {
      let startDate = new Date(event.startDate);
      let dayInAdvance =
        event.typeId === 1
          ? REM_10_DAYS
          : event.typeId === 5 || event.typeId === 6
          ? REM_5_DAYS
          : event.typeId === 11
          ? REM_30_DAYS
          : REM_7_DAYS;
      let sentDate = new Date(
        new Date(startDate).setDate(startDate.getDate() - dayInAdvance)
      );
        
      // create notification message 
      let notificationMsg =
        event.typeId === 1 || event.typeId === 2 || event.typeId === 5
          ? `Today you should start studying for the ${
              event.title
            } you are writing on the ${moment(startDate).format(
              SENTENCE_DATE_FORMAT
            )}.`
          : event.typeId === 11 ||
            event.typeId === 3 ||
            event.typeId === 4 ||
            event.typeId === 6
          ? `Today you should start doing the ${
              event.title
            } due on the ${moment(startDate).format(SENTENCE_DATE_FORMAT)}.`
          : "";

      //create notification heading
      let notificationHeading =
        event.typeId === 1 || event.typeId === 2 || event.typeId === 5
          ? `Study for ${event.title}`
          : event.typeId === 11 ||
            event.typeId === 3 ||
            event.typeId === 4 ||
            event.typeId === 6
          ? `Begin ${event.title}`
          : "";

      if (
        event.typeId === 1 ||
        event.typeId === 2 ||
        event.typeId === 3 ||
        event.typeId === 4 ||
        event.typeId === 5 ||
        event.typeId === 6 ||
        event.typeId === 11
      ) {
        // Create a new notification
        let notification = {
          userId: user?.profile.email,
          heading: notificationHeading,
          secondaryHeading: moment(sentDate).format(SENT_DATE_FORMAT),
          dateSent: new Date(
            sentDate.getFullYear(),
            sentDate.getMonth(),
            sentDate.getDate()
          ),
          notification: notificationMsg,
          id: event.id,
          isNotActive: false,
        };
        // dispatch request to create the notification on the database
        dispatch(createNotification(notification));
      }
    });
  }
}
