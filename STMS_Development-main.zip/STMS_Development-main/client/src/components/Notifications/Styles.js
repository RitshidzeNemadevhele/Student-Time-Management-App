import { makeStyles } from "@material-ui/core/styles";

// Material UI Styles
const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
  },
  notification: {
    minHeight: "100%",
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    flexBasis: "33.33%",
    flexShrink: 0,
  },
  secondaryHeading: {
    fontSize: theme.typography.pxToRem(15),
    color: theme.palette.text.secondary,
    display: "flex",
    flexDirection: "row",
    justifyContent: "center",
    marginLeft: "15px",
  },
  badge: {
    marginLeft: "15px",
    marginRight: "15px",
  },
  pageTitle: {
    display: "flex",
    flexDirection: "row",
    justifyContent: "center",
    margin: "1% 0% 1% 0%",
  },
  info: {
    display: "flex",
    flexDirection: "row",
    justifyContent: "center",
    margin: "1% 0% 1% 0%",
    fontSize: theme.typography.pxToRem(18),
  },
}));

export default useStyles;
