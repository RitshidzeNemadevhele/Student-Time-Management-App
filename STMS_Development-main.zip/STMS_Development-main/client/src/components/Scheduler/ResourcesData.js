//types of events
export const resourcesData = [
  {
    text: "Examination",
    id: 1,
    color: "#2196f3",
  },
  {
    text: "Test",
    id: 2,
    color: "#00bcd4",
  },
  {
    text: "Assignment",
    id: 3,
    color: "#009688",
  },
  {
    text: "Practical",
    id: 4,
    color: "#0d47a1",
  },
  {
    text: "Quiz",
    id: 5,
    color: "#673ab7",
  },
  {
    text: "Tutorial",
    id: 6,
    color: "#00e676",
  },
  {
    text: "Project",
    id: 11,
    color: "#1b5e20",
  },
  {
    text: "Workshop",
    id: 7,
    color: "#3f51b5",
  },
  {
    text: "Meeting",
    id: 8,
    color: "#00bfa5",
  },
  {
    text: "Reminder",
    id: 9,
    color: "#4caf50",
  },
  {
    text: "N/A",
    id: 10,
    color: "#1a237e",
  },
];

// add event to the todo list
export const todoListResource = [
  {
    text: "Yes",
    id: 1,
    color: "#4caf50",
  },
  {
    text: "No",
    id: 0,
    color: "#ff5722",
  },
];
