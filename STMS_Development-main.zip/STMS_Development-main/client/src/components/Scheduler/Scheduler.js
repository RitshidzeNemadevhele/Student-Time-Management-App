/* eslint-disable react/no-unused-state */
import * as React from "react";
import Paper from "@material-ui/core/Paper";
import { ViewState, EditingState } from "@devexpress/dx-react-scheduler";
import {
  Scheduler,
  Appointments,
  AppointmentForm,
  EditRecurrenceMenu,
  AllDayPanel,
  AppointmentTooltip,
  WeekView,
  DragDropProvider,
  MonthView,
  Toolbar,
  ViewSwitcher,
  DayView,
  DateNavigator,
  TodayButton,
  Resources,
  CurrentTimeIndicator,
  ConfirmationDialog,
} from "@devexpress/dx-react-scheduler-material-ui";
import { resourcesData, todoListResource } from "./ResourcesData";

const SHIFT_KEY = 16;
const SCHEDULER_ELEVATION = 9;
/*
Scheduler Page - React Class Component
*/
export default class Planner extends React.PureComponent {
  constructor({
    props,
    schedulerSettingsEx,
    appointments,
    handlDeleteEvent,
    handleAddEvent,
    handleChangeEvent,
  }) {
    super(props);
    this.state = {
      data: appointments,
      schedulerSettings: schedulerSettingsEx,
      resources: [
        {
          fieldName: "typeId",
          title: "Type Of Event:",
          instances: resourcesData,
        },
        {
          fieldName: "todoListAddId",
          title: "Add Event To The To-do List?",
          instances: todoListResource,
        },
      ],
      handleChangeEvent: handleChangeEvent,
      handlDeleteEvent: handlDeleteEvent,
      handleAddEvent: handleAddEvent,
      currentDate: new Date(),
      isShiftPressed: false,
      currentViewName: schedulerSettingsEx ? schedulerSettingsEx.defaultView.keyText:"work-week",
    };

    this.commitChanges = this.commitChanges.bind(this);

    this.currentDateChange = (currentDate) => {
      this.setState({ currentDate });
    };

    this.currentViewNameChange = (currentViewName) => {
      this.setState({ currentViewName });
    };

    this.onKeyDown = this.onKeyDown.bind(this);
    this.onKeyUp = this.onKeyUp.bind(this);
  }

  // Method called when an event has been changed
  commitChanges({ added, changed, deleted }) {
    this.setState((state) => {
      let { data, handleChangeEvent, handleAddEvent, handlDeleteEvent } = state;
      const { isShiftPressed } = this.state;

      if (added) {
        const startingAddedId =
          data.length > 0 ? data[data.length - 1].id + 1 : 0;
        data = [...data, { id: startingAddedId, ...added }];
        const event = data?.filter((event) => event.id === startingAddedId);
        delete event[0]["_id"];
        handleAddEvent(event);
      }
      if (changed) {
        if (isShiftPressed) {
          const changedAppointment = data.find(
            (appointment) => changed[appointment.id]
          );
          const startingAddedId =
            data.length > 0 ? data[data.length - 1].id + 1 : 0;

          data = [
            ...data,
            {
              ...changedAppointment,
              id: startingAddedId,
              ...changed[changedAppointment.id],
            },
          ];
          const event = data?.filter((event) => event.id === startingAddedId);
          delete event[0]["_id"];
          handleAddEvent(event);
        } else {
          data = data?.map((appointment) =>
            changed[appointment.id]
              ? { ...appointment, ...changed[appointment.id] }
              : appointment
          );
          const event = data?.filter((event) => changed[event.id]);
          handleChangeEvent(event);
        }
      }
      if (deleted !== undefined) {
        let deletedEvent = data?.filter(
          (appointment) => appointment.id === deleted
        )[0];
        data = data?.filter((appointment) => appointment.id !== deleted);
        handlDeleteEvent(deletedEvent);
      }
      return { data };
    });
  }

  // Copy Event Fuctionality
  componentDidMount() {
    window.addEventListener("keydown", this.onKeyDown);
    window.addEventListener("keyup", this.onKeyUp);
  }

  componentWillUnmount() {
    window.removeEventListener("keydown", null);
    window.removeEventListener("keyup", null);
  }

  onKeyDown(event) {
    if (event.keyCode === SHIFT_KEY) {
      this.setState({ isShiftPressed: true });
    }
  }

  onKeyUp(event) {
    if (event.keyCode === SHIFT_KEY) {
      this.setState({ isShiftPressed: false });
    }
  }

  render() {
    const { currentDate, data, resources, currentViewName, schedulerSettings } =
      this.state;
    return (
      // Scheduler react component rendering
      <Paper elevation={SCHEDULER_ELEVATION} >
        <Scheduler data={data} firstDayOfWeek={schedulerSettings ? schedulerSettings.weekStartDay.index : 0}>
          <ViewState
            currentDate={currentDate}
            currentViewName={currentViewName}
            onCurrentViewNameChange={this.currentViewNameChange}
            onCurrentDateChange={this.currentDateChange}
          />
          <EditingState onCommitChanges={this.commitChanges} />
          <WeekView  startDayHour={
              schedulerSettings ? schedulerSettings.dayStartTime.decimalTime : 8
            }
            endDayHour={
              schedulerSettings ? schedulerSettings.dayEndTime.decimalTime : 22
            } />
          <WeekView
            name="work-week"
            displayName="Work Week"
            excludedDays={[0, 6]}
            startDayHour={
              schedulerSettings ? schedulerSettings.dayStartTime.decimalTime : 8
            }
            endDayHour={
              schedulerSettings ? schedulerSettings.dayEndTime.decimalTime : 22
            }
          />
          <MonthView />
          <DayView
            startDayHour={
              schedulerSettings ? schedulerSettings.dayStartTime.decimalTime : 8
            }
            endDayHour={
              schedulerSettings ? schedulerSettings.dayEndTime.decimalTime : 22
            }
          />

          <Toolbar />
          <DateNavigator />
          <TodayButton />
          <ViewSwitcher />
          <AllDayPanel />
          <EditRecurrenceMenu />
          <Appointments />
          <ConfirmationDialog ignoreDelete />
          <AppointmentTooltip showDeleteButton showOpenButton showCloseButton />
          <AppointmentForm />
          <Resources data={resources} mainResourceName="typeId" />
          <DragDropProvider />
          <CurrentTimeIndicator />
        </Scheduler>
      </Paper>
    );
  }
}
