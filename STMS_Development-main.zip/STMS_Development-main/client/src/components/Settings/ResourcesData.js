// Week start days combo box options
export const weekStartdays = [
    { day: "Sunday", index: 0 },
    { day: "Monday", index: 1 },
    { day: "Tuesday", index: 2 },
    { day: "Wednesday", index: 3 },
    { day: "Thurday", index: 4 },
    { day: "Friday", index: 5 },
    { day: "Saturday", index: 6 },
  ];

  // default view combo box options
  export const defaultViews = [
    { view: "Work Week", keyText: "work-week" },
    { view: "Week", keyText: "Week" },
    { view: "Month", keyText: "Month" },
    { view: "Day", keyText: "Day" },
  ];