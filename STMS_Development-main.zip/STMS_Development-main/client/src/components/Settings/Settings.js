import {
  Button,
  Grid,
  IconButton,
  List,
  ListItem,
  ListItemIcon,
  Paper,
  Tooltip,
  Typography,
} from "@material-ui/core";
import React, { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import useStyles from "./Styles";
import AdapterDateFns from "@mui/lab/AdapterDateFns";
import LocalizationProvider from "@mui/lab/LocalizationProvider";
import TimePicker from "@mui/lab/TimePicker";
import MenuItem from "@mui/material/MenuItem";
import SaveOutlinedIcon from "@mui/icons-material/SaveOutlined";
import BuildOutlinedIcon from "@mui/icons-material/BuildOutlined";
import { weekStartdays, defaultViews } from "./ResourcesData";
import CalendarTodayOutlinedIcon from "@mui/icons-material/CalendarTodayOutlined";
import SettingsBackupRestoreOutlinedIcon from "@mui/icons-material/SettingsBackupRestoreOutlined";
import Alert from "../../components/Alert/Alert";
import { changeSettings, createSettings } from "../../actions/settings";

var alertType;
var alertMessage;
var alertTitle;

const PAPER_ELEVATION = 9;

/*
Settings Page - React Component
*/
const Settings = () => {
  document.title = "STMS - Settings";
  const classes = useStyles();
  const [dayStartTime, setDayStartTime] = useState(
    new Date(2021, 1, 1, 8, 0, 0)
  );
  const [dayEndTime, setDayEndTime] = useState(new Date(2021, 1, 1, 22, 0, 0));
  const [weekStartDay, setWeekStartDay] = useState(weekStartdays[0].day);
  const [defaultView, setDefaultView] = useState(defaultViews[0].view);
  const [showAlert, setShowAlert] = useState(false);
  const [user] = useState(JSON.parse(localStorage.getItem("profile")));
  const [settings, setSettings] = useState(
    JSON.parse(localStorage.getItem("settings"))
  );
  const dispatch = useDispatch();

  useEffect(() => {
    // populate the scheduler setting form
    if (settings) {
      setDayStartTime(new Date(settings?.dayStartTime.time));
      setDayEndTime(new Date(settings?.dayEndTime.time));
      setWeekStartDay(settings?.weekStartDay.day);
      setDefaultView(settings?.defaultView.view);
    }
  }, [settings]);
  
  //Method to convert a string to a title case
  const toTitleCase = (string) => {
    return string.replace(/\w\S*/g, function (txt) {
      return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
    });
  };

  // Method to get decimal value of the given time
  const getDecimalTime = (time) => {
    return time.getHours() + time.getMinutes() / 60;
  };

  // Method  to restore default settings  
  const defaultSettings = () => {
    handleSubmit(true);
  };

  // Method to get current settings / default settings
  const getSettings = (reset) => {
    var newSettings = {
      userId: user?.profile?.email,
      dayStartTime: {
        time: !reset ? dayStartTime : new Date(2021, 1, 1, 8, 0, 0),
        decimalTime: getDecimalTime(
          !reset ? dayStartTime : new Date(2021, 1, 1, 8, 0, 0)
        ),
      },
      dayEndTime: {
        time: !reset ? dayEndTime : new Date(2021, 1, 1, 22, 0, 0),
        decimalTime: getDecimalTime(
          !reset ? dayEndTime : new Date(2021, 1, 1, 22, 0, 0)
        ),
      },
      weekStartDay: weekStartdays?.filter(
        (weekStartDayArg) =>
          weekStartDayArg.day === (!reset ? weekStartDay : weekStartdays[0].day)
      )[0],
      defaultView: defaultViews?.filter(
        (defaultViewArg) =>
          defaultViewArg.view === (!reset ? defaultView : defaultViews[0].view)
      )[0],
    };
    return newSettings;
  };

  // Method to handle the submit button event
  const handleSubmit = (reset = false) => {
    var newSettings = getSettings(typeof reset === "boolean" ? true : false);
    if (newSettings.dayEndTime.time > newSettings.dayStartTime.time) {
      if (settings === null) {
        // Dispatch request to create new settings
        dispatch(createSettings(newSettings)).then(function (response) {
          if (Array.isArray(response)) {
            alertTitle = toTitleCase(response[2]);
            alertType = response[2];
            alertMessage = response[0];
            setShowAlert(false);
            setShowAlert(true);

            setTimeout(function () {
              setShowAlert(false);
            }, 2000);
          }
        });
      } else {
        // Dispatch request to update settings
        dispatch(changeSettings(newSettings)).then(function (response) {
          if (Array.isArray(response)) {
            alertTitle = toTitleCase(response[2]);
            alertType = response[2];
            alertMessage = response[0];
            setShowAlert(false);
            setShowAlert(true);

            setTimeout(function () {
              setShowAlert(false);
            }, 2000);
          }
        });
      }
      setSettings(newSettings);
    } else {
      // Show alert
      var response = [
        `Day Start Time must be less than Day End Time`,
        400,
        "WARNING",
      ];

      alertTitle = toTitleCase(response[2]);
      alertType = response[2];
      alertMessage = response[0];
      setShowAlert(false);
      setShowAlert(true);

      setTimeout(function () {
        setShowAlert(false);
      }, 2000);
    }
  };

  function handleClosingAlert() {
    setShowAlert(false);
  }

  return (
    <Grid
      container
      direction="column"
      justifyContent="center"
      alignItems="center"
    >
      <Paper elevation={PAPER_ELEVATION} className={classes.paper}>
        <List>
          <ListItem className={classes.resetSettingsButton}>
            <ListItemIcon>
              <CalendarTodayOutlinedIcon />
              <BuildOutlinedIcon className={classes.menuIcon} />
              <Typography className={classes.title}>
                Scheduler Settings
              </Typography>
            </ListItemIcon>

            <Tooltip title="Default Settings" placement="left">
              <IconButton onClick={defaultSettings}>
                <SettingsBackupRestoreOutlinedIcon fontSize={"large"} />
              </IconButton>
            </Tooltip>
          </ListItem>
        </List>

        <Box
          component="form"
          sx={{
            "& .MuiTextField-root": { m: 2, width: "30ch" },
          }}
          noValidate
          autoComplete="off"
        >
          <Box>
            <LocalizationProvider dateAdapter={AdapterDateFns}>
              <TimePicker
                label="Day Start Time"
                value={dayStartTime}
                onChange={setDayStartTime}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    helperText="Please select day start time"
                  />
                )}
              />
            </LocalizationProvider>
            <LocalizationProvider dateAdapter={AdapterDateFns}>
              <TimePicker
                label="Day End Time"
                value={dayEndTime}
                onChange={setDayEndTime}
                renderInput={(params) => (
                  <TextField
                    {...params}
                    helperText="Please select day end time"
                  />
                )}
                minTime={
                  new Date(
                    new Date(dayStartTime).setHours(dayStartTime.getHours() + 1)
                  )
                }
                maxTime={new Date(2021, 1, 1, 23, 59)}
              />
            </LocalizationProvider>
          </Box>
          <Box>
            <TextField
              id="week-start-day"
              select
              label="Week Start Day"
              value={weekStartDay}
              onChange={(event, newValue) => {
                setWeekStartDay(newValue.props.value);
              }}
              helperText="Please select week start day"
            >
              {weekStartdays.map((option) => (
                <MenuItem key={option.index} value={option.day}>
                  {option.day}
                </MenuItem>
              ))}
            </TextField>
            <TextField
              id="default-view"
              select
              label="Default View"
              value={defaultView}
              onChange={(event, newValue) => {
                setDefaultView(newValue.props.value);
              }}
              helperText="Please select default view"
            >
              {defaultViews.map((option) => (
                <MenuItem key={option.keyText} value={option.view}>
                  {option.view}
                </MenuItem>
              ))}
            </TextField>
          </Box>
        </Box>
        <Box className={classes.saveButtonBox}>
          <Button
            variant="outlined"
            startIcon={<SaveOutlinedIcon />}
            className={classes.saveButton}
            size="large"
            onClick={handleSubmit}
          >
            Save Changes
          </Button>
        </Box>
        {/* Provide user with feedback*/}
        {showAlert ? (
          <Alert
            alertType={alertType}
            message={alertMessage}
            title={alertTitle}
            handleCloseAlert={handleClosingAlert}
          />
        ) : null}
      </Paper>
    </Grid>
  );
};

export default Settings;
