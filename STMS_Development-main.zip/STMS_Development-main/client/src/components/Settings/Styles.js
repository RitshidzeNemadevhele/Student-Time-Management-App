import { makeStyles } from "@material-ui/core/styles";

// Material UI Styles
const useStyles = makeStyles((theme) => ({
  root: {
    color: theme.palette.primary.light,
  },
  saveButton: {
    "&:hover": {
      backgroundColor: "#00bcd4",
    },
    backgroundColor: "#0F5F8A",
    marginTop: "15px",
    marginBottom: "15px",
  },
  saveButtonBox: {
    display: "flex",
    flexDirection: "row",
    justifyContent: "center",
  },
  title: {
    fontSize: theme.typography.pxToRem(18),
  },
  menuIcon: {
    marginRight: "8px",
  },
  paper: {
    borderRadius: "10px",
    backgroundColor: "#0f5f8a",
  },
  resetSettingsButton: {
    justifyContent: "space-between",
    paddingRight: "0px",
  }
}));

export default useStyles;
