import React, { useState } from "react";
import { AiOutlineFileDone } from "react-icons/ai";
import { MdPlaylistAdd } from "react-icons/md";

/*
Todo List Item Input Form - React Component
*/
function TodoForm(props) {
  const [input, setInput] = useState(props.edit ? props.edit.title : "");

  //Method to check if the id exist in the todo list
  const idExist = (id, array) => {
    var found = -1;
    for (var i = 0; i < props.length; i++) {
      if (array[i].id === id) {
        found = i;
        break;
      }
    }
    return found;
  };

  //Method to generate todo id
  const generateTodoId = () => {
    var id = Math.floor(Math.random() * 10000);
    while (idExist(id, props.todos) >= 0) {
      id = Math.floor(Math.random() * 10000);
    }
    return id;
  };

  const handleChange = (e) => {
    setInput(e.target.value);
  };

   // Method to handle add button event
  const handleSubmit = (e) => {
    e.preventDefault();

    props.onSubmit({
      id: generateTodoId(),
      title: input.trim(),
      isComplete: false,
    });
    setInput("");
  };

  return (
    <form onSubmit={handleSubmit} className="todo-form">
      {props.edit ? (
        <>
          <input
            placeholder="Update your item"
            value={input}
            onChange={handleChange}
            name="title"
            className="todo-input edit"
          />
          <button onClick={handleSubmit} className="todo-button edit">
            <AiOutlineFileDone size={40} />
          </button>
        </>
      ) : (
        <>
          <input
            placeholder="Add item"
            value={input}
            onChange={handleChange}
            name="title"
            className="todo-input"
          />
          <button
            data-tip="Add Todo"
            onClick={handleSubmit}
            className="todo-button"
          >
            <MdPlaylistAdd size={40} />
          </button>
        </>
      )}
    </form>
  );
}

export default TodoForm;
