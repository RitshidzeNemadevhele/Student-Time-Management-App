import React, { useState, useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import TodoForm from "./TodoForm";
import Todo from "./Todo";
import { changeEvent } from "../../actions/events";

/*
Todo List Page - React Component
*/
function TodoList({ handleAddTodoList, handleChangeTodoList }) {
  const dispatch = useDispatch();
  const [todos, setTodos] = useState([]);
  const [user] = useState(JSON.parse(localStorage.getItem("profile")));
  const [events, setEvents] = useState(useSelector((state) => state.events));
  const [todolists, setTodolists] = useState(
    useSelector((state) => state.todolist)
  );

  // events to add to the todo list from the scheduler
  const [eventsToAdd, setEventsToAdd] = useState(
    events
      ?.filter((event) => event.todoListAddId === 1)
      ?.sort(function (a, b) {
        var dateA = new Date(a.startDate),
          dateB = new Date(b.startDate);
        return dateA - dateB;
      })
  );

  useEffect(() => {
    // events to add to the todo list from the scheduler
    setEventsToAdd(
      events
        ?.filter((event) => event.todoListAddId === 1)
        ?.sort(function (a, b) {
          var dateA = new Date(a.startDate),
            dateB = new Date(b.startDate);
          return dateA - dateB;
        })
    );
  }, [events]);

  useEffect(() => {
    setTodos(
      todolists[0] !== undefined ? todolists[0]?.items?.filter(() => true) : []
    );
  }, [todolists]);

    // Event lister
  document.addEventListener("DOMContentLoaded", function () {
    getData();
  });

  // Method to get events and todo list Items
  function getData() {
    getEvents();
    getTodoItems();
  }

  function getEvents() {
    setEvents(JSON.parse(localStorage.getItem("events")));
  }

  function getTodoItems() {
    setTodolists(
      JSON.parse(localStorage.getItem("todolists"))?.filter(() => true)
    );
  }

  //Method to update the todo list
  function updateTodoList(items) {
    let _id = todolists[0]?._id;
    const todolist = {
      _id: _id,
      userId: user?.profile.email,
      items: items,
    };
    handleChangeTodoList(todolist);
  }

  // Method to  add item to the do the to do list
  const addTodo = (todo, addEvent = false) => {
    if (addEvent) {
    } else if (!todo.title || /^\s*$/.test(todo.title)) {
      return;
    }
    let todoList = JSON.parse(localStorage.getItem("todolists"))[0];

    const newTodos = addEvent
      ? todoList !== undefined
        ? [...todoList?.items, ...todo]
        : [...todo]
      : [...todos, todo];

    setTodos(newTodos);
    let todolist = null;

    if (todoList !== undefined) {
      updateTodoList(newTodos);
    } else {
      todolist = {
        userId: user?.profile.email,
        items: newTodos,
      };
      handleAddTodoList(todolist);
    }
  };

  // Method to update the to do list
  const updateTodo = (todoId, newValue, updateEvent = false) => {
    if (updateEvent) {
    } else if (!newValue.title || /^\s*$/.test(newValue.title)) {
      return;
    }

    let todoList = JSON.parse(localStorage.getItem("todolists"))[0]?.items;

    let updatedTodos;
    updateEvent
      ? newValue[0].forEach((newItem) => {
          updatedTodos = todoList?.map((item) =>
            item.id === newItem.id ? newItem : item
          );
          todoList = updatedTodos;
        })
      : (updatedTodos = todos?.map((item) =>
          item.id === todoId ? newValue : item
        ));

    if (updatedTodos !== undefined) {
      setTodos(updatedTodos);
      updateTodoList(updatedTodos);
    }
    if (newValue[1]?.length > 0) addTodo(newValue[1], true);

    let event = !updateEvent
      ? eventsToAdd?.filter((event) => event.id === todoId)
      : null;
    if (event?.length > 0 && !updateEvent) {
      event[0].title = newValue.title;
      dispatch(changeEvent(event[0]));
    }
  };

  // Method to remove item form the todo list
  const removeTodo = (todoId) => {
    // return a filtered to do list(with out the removed item)
    const removedArr = [...todos]?.filter((todo) => todo.id !== todoId);
    setTodos(removedArr);
    updateTodoList(removedArr);
    let event = eventsToAdd?.filter((event) => event.id === todoId);
    if (event?.length > 0) {
      event[0].todoListAddId = 0;
      dispatch(changeEvent(event[0]));
    }
  };

  // Method to update the isComplete field of the todolist items
  const completeTodo = (id) => {
    let updatedTodos = todos?.map((todo) => {
      if (todo.id === id) {
        todo.isComplete = !todo.isComplete;
      }
      return todo;
    });
    setTodos(updatedTodos);
    updateTodoList(updatedTodos);
  };

  // Method to check if item already exist on the to do list
  function alreadyExist(id) {
    let todoList = JSON.parse(localStorage.getItem("todolists"))[0];
    return todoList
      ? todoList.items?.filter((item) => item.id === id).length > 0
      : false;
  }

  // Method to get the isComplete field of the todo list item
  function getIsComplete(id) {
    let todoList = JSON.parse(localStorage.getItem("todolists"))[0];
    return todoList
      ? todoList.items?.filter((item) => item.id === id)[0].isComplete
      : false;
  }

  // Method to get the title field of the todo list item
  function getTitle(id) {
    let todoList = JSON.parse(localStorage.getItem("todolists"))[0];
    return todoList
      ? todoList.items?.filter((item) => item.id === id)[0].title
      : false;
  }

  // Method to add/update events form the scheduler 
  function addEvents() {
    let listOfEventToAdd = [];
    let listOfEventToUpdate = [];
    eventsToAdd.forEach((event) => {
      if (!alreadyExist(event.id)) {
        listOfEventToAdd.push({
          title: event.title,
          id: event.id,
          isComplete: false,
        });
      } else {
        if (event.title !== getTitle(event.id)) {
          listOfEventToUpdate.push({
            title: event.title,
            id: event.id,
            isComplete: getIsComplete(event.id),
          });
        }
      }
    });
    updateTodo(0, [listOfEventToUpdate, listOfEventToAdd], true);
  }

  useEffect(() => {
    addEvents();
    // eslint-disable-next-line
  }, []);

  return (
    <>
      <h1 className="todo-list-title">What's the Plan for Today?</h1>
      <TodoForm todos={todos} length={todos?.length} onSubmit={addTodo} />
      <Todo
        todos={todos}
        completeTodo={completeTodo}
        removeTodo={removeTodo}
        updateTodo={updateTodo}
      />
    </>
  );
}

export default TodoList;
