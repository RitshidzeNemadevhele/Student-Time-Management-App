//Constant for authenticate/login out 
export const AUTH = "AUTH";
export const LOGOUT = "LOGOUT";

// Constants for events
export const CREATE = "CREATE";
export const DELETE = "DELETE";
export const UPDATE = "UPDATE";
export const FETCH_ALL = "FETCH_ALL";

//Constant for notifications
export const CREATE_NOTIFICATION = "CREATE_NOTIFICATION";
export const FETCH_ALL_NOTIFICATIONS = "FETCH_ALL_NOTIFICATIONS";

//Constants for todolist
export const CREATE_TODOLIST = "CREATE_TODOLIST";
export const FETCH_ALL_TODOLIST = "FETCH_ALL_TODOLIST";

//Costants for settings
export const FETCH_SETTINGS = "FETCH_SETTINGS";

//Constans for Alert messages
export const ERROR = "ERROR";
export const WARNING = "WARNING";
export const INFO = "INFO";
export const SUCCESS = "SUCCESS";
