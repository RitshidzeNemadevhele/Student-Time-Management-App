import React from "react";
import MainPage from "../pages/Index";
import HomeWorkOutlinedIcon from "@mui/icons-material/HomeWorkOutlined";
import PageTitleComp from "../components/Navbar/PageTitle";
import Home from "../components/Home/Home";

/*
Home Page
*/
function App() {
  document.title = "STMS - Home";
  return (
    <MainPage
      componentToRender={<Home />}
      PageTitle={
        <PageTitleComp Icon={<HomeWorkOutlinedIcon />} Title={"Home"} />
      }
    />
  );
}

export default App;
