import React, { useState, useEffect, useCallback } from "react";
import { useDispatch } from "react-redux";
import { LOGOUT } from "../constants/actionTypes";
import { useHistory } from "react-router";
import decode from "jwt-decode";
import ResponsiveDrawer from "../components/Navbar/Navbar";
import { useLocation } from "react-router-dom";
import { getEvents } from "../actions/events";
import { getNotifications } from "../actions/notifications";
import { getToDoList } from "../actions/todolist";
import { getSettings } from "../actions/settings";

/*
Main Page
*/
const MainPage = ({ componentToRender, PageTitle, getUser }) => {
  const [user, setUser] = useState(JSON.parse(localStorage.getItem("profile")));
  const dispatch = useDispatch();
  const history = useHistory();
  const location = useLocation();

  try {
    getUser(user);
  } catch (error) {}

  // Logout Method
  const logout = useCallback(() => {
    dispatch({ type: LOGOUT });
    history.push("/login");
    setUser(null);
    try {
      getUser(user);
    } catch (error) {}
  }, [history, dispatch, getUser, user]);

  /*
  Get All Data of the current user from the database
  */
  useEffect(() => {
    dispatch(getEvents(user?.profile.email));
    dispatch(getNotifications(user?.profile.email));
    dispatch(getToDoList(user?.profile.email));
    dispatch(getSettings(user?.profile.email));
  }, [dispatch, location, user]);

  // Log out the use after their token has expired
  useEffect(() => {
    const token = user?.token;
    if (token) {
      const decodeToken = decode(token);
      if (decodeToken.exp * 1000 < new Date().getTime()) {
        logout();
      }
    }
  }, [location, user, logout]);

  return (
    <div>
      <ResponsiveDrawer
        user={user}
        logOut={logout}
        componentToRender={componentToRender}
        PageTitle={PageTitle}
      />
    </div>
  );
};

export default MainPage;
