import { ThemeProvider, Paper, createTheme } from "@material-ui/core";
import React from "react";
import Form from "../components/Auth/Form";
import { makeStyles } from "@material-ui/core/styles";
import Image from "../images/TimeTracking.jpg";

// Material UI Styles
const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    padding: theme.spacing(1),
    zIndex: theme.zIndex.drawer - 1,
    height: "auto",
    minHeight: "100vh",
    backgroundImage: `url(${Image})`,
    backgroundSize: "cover",
    backgroundPosition: "center",
  },
}));

/*
Login Page
*/
const Login = () => {
  document.title = "STMS - Login";
  const classes = useStyles();

  //Create Dark Theme
  const darkTheme = createTheme({
    palette: {
      type: "dark",
    },
  });

  return (
    <ThemeProvider theme={darkTheme}>
      <Paper className={classes.root}>
        <Form isSignUp={false} />
      </Paper>
    </ThemeProvider>
  );
};

export default Login;
