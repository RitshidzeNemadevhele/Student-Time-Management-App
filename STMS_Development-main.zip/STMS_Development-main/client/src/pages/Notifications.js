import Notification from "../components/Notifications/Notification";
import React, { useState } from "react";
import MainPage from "../pages/Index";
import { CreateNotificationsAI } from "../components/Notifications/Notifications";

/*
Notification Page
*/
function App() {
  CreateNotificationsAI();
  document.title = "STMS - Notifications";

  // get User Notifications
  const [Notifications] = useState(
    JSON.parse(localStorage.getItem("notifications"))
      ?.sort(function (a, b) {
        var dateA = new Date(a.dateSent),
          dateB = new Date(b.dateSent);
        return dateB - dateA;
      })
      ?.filter((notification) => new Date(notification.dateSent) <= new Date())
  );
  return (
    <MainPage
      componentToRender={<Notification Notifications={Notifications} />}
    />
  );
}

export default App;
