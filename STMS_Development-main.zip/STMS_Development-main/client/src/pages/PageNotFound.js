import {
  ThemeProvider,
  Paper,
  createTheme,
  Typography,
  Button,
  Divider,
  Grid,
} from "@material-ui/core";
import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import { Link } from "react-router-dom";
import HomeRoundedIcon from "@mui/icons-material/HomeRounded";
import { Box } from "@mui/system";
import Image from "../images/TimeTracking.jpg";

const PAPER_ELEVATION = 9;

// Material UI Styles
const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    padding: theme.spacing(1),
    zIndex: theme.zIndex.drawer - 1,
    height: "auto",
    minHeight: "100vh",
    backgroundImage: `url(${Image})`,
    backgroundSize: "cover",
    backgroundPosition: "center",
  },
  homeButton: {
    "&:hover": {
      backgroundColor: "#00bcd4",
    },
    backgroundColor: "#0F5F8A",
    marginTop: "15px",
    marginBottom: "15px",
  },
  paper: {
    borderRadius: "10px",
    backgroundColor: "#0f5f8a",
    padding: "20px",
  },
  homeButtonBox: {
    display: "flex",
    flexDirection: "row",
    justifyContent: "center",
  },
  pageNotFoundTitle: {
    display: "flex",
    flexDirection: "row",
    justifyContent: "center",
    marginTop: "10px",
    marginBottom: "15px",
  },
}));

/*
PageNotFound Page
*/
const PageNotFound = () => {
  document.title = "STMS - Page Not Found!";
  const classes = useStyles();
  const darkTheme = createTheme({
    palette: {
      type: "dark",
    },
  });
  
  return (
    <ThemeProvider theme={darkTheme}>
      <Paper className={classes.root}>
        <Grid
          container
          direction="column"
          justifyContent="center"
          alignItems="center"
        >
          <Box
            display="flex"
            justifyContent="center"
            alignItems="center"
            minHeight="50vh"
          >
            <Paper elevation={PAPER_ELEVATION} className={classes.paper}>
              <Typography variant="h3" className={classes.pageNotFoundTitle}>
                Oops!
              </Typography>
              <Typography variant="h5" className={classes.homeButtonBox}>
                404 - Page Not Found!
              </Typography>
              <Typography className={classes.homeButtonBox}>
                Sorry, an error has occured, Requested page not found!
              </Typography>
              <Box className={classes.homeButtonBox}>
                <Button
                  className={classes.homeButton}
                  elevation
                  variant="outlined"
                  startIcon={<HomeRoundedIcon fontSize={"large"} />}
                  size="large"
                  component={Link}
                  to={"/"}
                >
                  <Divider orientation="vertical" variant="middle" flexItem />{" "}
                  Take Me Home
                </Button>
              </Box>
            </Paper>
          </Box>
        </Grid>
      </Paper>
    </ThemeProvider>
  );
};

export default PageNotFound;
