import React, { useState } from "react";
import { useSelector } from "react-redux";
import MainPage from "../pages/Index";
import Scheduler from "../components/Scheduler/Scheduler";
import PageTitleComp from "../components/Navbar/PageTitle";
import EventOutlinedIcon from "@mui/icons-material/EventOutlined";
import { useDispatch } from "react-redux";
import { createEvent, deleteEvent, changeEvent } from "../actions/events";
var user;

/*
Scheduler Page
*/
function SchedulerPage() {
  document.title = "STMS - Scheduler";

   // get User Events
  const [events, setEvents] = useState(
    JSON.parse(localStorage.getItem("events"))
  );

  // get User Settings
  const [settings] = useState(JSON.parse(localStorage.getItem("settings")));

  const dispatch = useDispatch();

  // Method to handle adding user events
  function handleAddEvent(Event) {
    Event[0]["userId"] = user?.profile?.email;
    dispatch(createEvent(Event[0]));
  }

  // Method to handle deleting user events
  function handlDeleteEvent(Event) {
    dispatch(deleteEvent(Event));
  }

   // Method to handle updating user events
  function handleChangeEvent(Event) {
    dispatch(changeEvent(Event[0]));
  }
  
  //Method to get the current user
  function GetUser(userArg) {
    user = userArg;
    setEvents(useSelector((state) => state.events));
  }

  return (
    <MainPage
      getUser={GetUser}
      componentToRender={
        <Scheduler
          appointments={events}
          handleAddEvent={handleAddEvent}
          handlDeleteEvent={handlDeleteEvent}
          handleChangeEvent={handleChangeEvent}
          schedulerSettingsEx={settings}
        />
      }
      PageTitle={
        <PageTitleComp Icon={<EventOutlinedIcon />} Title={"Scheduler"} />
      }
    />
  );
}

export default SchedulerPage;
