import React from "react";
import Settings from "../components/Settings/Settings";
import MainPage from "./Index";
import PageTitle from "../components/Navbar/PageTitle";
import SettingsOutlinedIcon from "@mui/icons-material/SettingsOutlined";

/*
Settings Page
*/
const SettingsPage = () => {
  return (
    <MainPage
      componentToRender={<Settings />}
      PageTitle={
        <PageTitle Icon={<SettingsOutlinedIcon />} Title={"Setttings"} />
      }
    />
  );
};

export default SettingsPage;
