import { ThemeProvider, Paper, createTheme } from "@material-ui/core";
import React from "react";
import Form from "../components/Auth/Form";
import { makeStyles } from "@material-ui/core/styles";
import Image from "../images/TimeTracking.jpg";

// Material UI Styles
const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
    padding: theme.spacing(1),
    zIndex: theme.zIndex.drawer - 1,
    height: "auto",
    minHeight: "100vh",
    backgroundImage: `url(${Image})`,
    backgroundSize: "cover",
    backgroundPosition: "center",
  },
}));

/*
Signup Page
*/
const SignUp = () => {
  document.title = "STMS - Signup";
  const classes = useStyles();

   //Create Dark Theme
  const darkTheme = createTheme({
    palette: {
      type: "dark",
    },
  });

  return (
    <ThemeProvider theme={darkTheme}>
      <Paper className={classes.root}>
        <Form isSignUp={true} />
      </Paper>
    </ThemeProvider>
  );
};

export default SignUp;
