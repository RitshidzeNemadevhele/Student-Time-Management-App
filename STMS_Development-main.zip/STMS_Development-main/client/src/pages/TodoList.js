import React from "react";
import TodoList from "../components/TodoList/TodoList";
import MainPage from "../pages/Index";
import { useDispatch } from "react-redux";
import AssignmentOutlinedIcon from "@mui/icons-material/AssignmentOutlined";
import PageTitleComp from "../components/Navbar/PageTitle";
import { createToDoList, changeToDoList } from "../actions/todolist";
import { Box } from "@mui/system";

/*
TodoList Page
*/
function TodoListPage() {
  document.title = "STMS - Todo List";
  const dispatch = useDispatch();

  // Method to handle adding user todo list
  function handleAddTodoList(TodoList) {
    dispatch(createToDoList(TodoList));
  }
  
  // Method to handle updating user todo list
  function handleChangeTodoList(TodoList) {
    dispatch(changeToDoList(TodoList));
  }

  return (
    <MainPage
      componentToRender={
        <Box className="todo-app">
          <TodoList
            handleAddTodoList={handleAddTodoList}
            handleChangeTodoList={handleChangeTodoList}
          />
        </Box>
      }
      PageTitle={
        <PageTitleComp Icon={<AssignmentOutlinedIcon />} Title={"To-do List"} />
      }
    />
  );
}

export default TodoListPage;
