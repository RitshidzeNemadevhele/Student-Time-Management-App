import { AUTH, LOGOUT } from "../constants/actionTypes";

/*
User authentication reducers
*/
const authReducers = (state = {}, action) => {
  switch (action.type) {
    case AUTH:
      localStorage.setItem("profile", JSON.stringify({ ...action?.data }));
      return { ...action?.data };
    case LOGOUT:
      localStorage.clear();
      return state;
    default:
      return state;
  }
};

export default authReducers;
