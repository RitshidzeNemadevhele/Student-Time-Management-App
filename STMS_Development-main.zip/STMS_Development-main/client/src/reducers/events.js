import { FETCH_ALL, CREATE } from "../constants/actionTypes";

/*
User Events reducers
*/
const events = (events = [], action) => {
  switch (action.type) {
    case FETCH_ALL:
      localStorage.setItem("events", JSON.stringify(action?.payload));
      return action?.payload;
    case CREATE:
      localStorage.setItem(
        "events",
        JSON.stringify([...events, action?.payload])
      );
      return [...events, action?.payload];
    default:
      return events;
  }
};

export default events;
