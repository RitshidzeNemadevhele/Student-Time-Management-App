import { combineReducers } from "redux";

import authReducers from "./auth";
import events from "./events";
import notifications from "./notifications";
import todolist from "./todolist";
import settings from "./settings";

/*
Combining All reducers
*/
export const reducers = combineReducers({
  authReducers,
  events,
  notifications,
  todolist,
  settings,
});
