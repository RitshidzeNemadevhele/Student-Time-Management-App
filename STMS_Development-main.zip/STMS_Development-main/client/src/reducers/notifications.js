import {
  FETCH_ALL_NOTIFICATIONS,
  CREATE_NOTIFICATION,
} from "../constants/actionTypes";

/*
User Notification reducers
*/
const notifications = (notifications = [], action) => {
  switch (action.type) {
    case FETCH_ALL_NOTIFICATIONS:
      localStorage.setItem("notifications", JSON.stringify(action?.payload));
      return action?.payload;
    case CREATE_NOTIFICATION:
      localStorage.setItem(
        "notifications",
        JSON.stringify([...notifications, action?.payload])
      );
      return [...notifications, action?.payload];
    default:
      return notifications;
  }
};

export default notifications;
