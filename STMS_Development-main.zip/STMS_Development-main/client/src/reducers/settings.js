import { FETCH_SETTINGS } from "../constants/actionTypes";

/*
User Settings reducers
*/
const settings = (state = {}, action) => {
  switch (action.type) {
    case FETCH_SETTINGS:
      action?.payload.length > 0
        ? localStorage.setItem("settings", JSON.stringify(...action?.payload))
        : localStorage.setItem("settings", JSON.stringify(null));
      return action?.payload.length > 0 ? { ...action?.payload } : null;
    default:
      return state;
  }
};

export default settings;
