import { FETCH_ALL_TODOLIST, CREATE_TODOLIST } from "../constants/actionTypes";

/*
User TodoList reducers
*/
const todolist = (todolist = [], action) => {
  switch (action.type) {
    case FETCH_ALL_TODOLIST:
      localStorage.setItem("todolists", JSON.stringify(action?.payload));
      return action?.payload;
    case CREATE_TODOLIST:
      localStorage.setItem(
        "todolists",
        JSON.stringify([...todolist, action?.payload])
      );
      return [...todolist, action?.payload];
    default:
      return todolist;
  }
};

export default todolist;
