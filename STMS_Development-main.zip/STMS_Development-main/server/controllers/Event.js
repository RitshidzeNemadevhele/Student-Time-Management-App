import Event from "../models/Event.js";

/*
Async Method to get user events from the database
*/
export const getEvents = async (req, res) => {
  const { userId } = req.body;
  try {
    const events = await Event.find({ userId: userId });
    res.status(200).json(events);
  } catch (error) {
    return res.status(404).json({
      message: ["Something went wrong. Try again later.", 404, "ERROR"],
    });
  }
};

/*
Async Method to create user event on the database
*/
export const createEvent = async (req, res) => {
  const event = req.body;
  const newEvent = new Event(event);
  try {
    await newEvent.save();
    res.status(201).json(newEvent);
  } catch (error) {
    return res.status(409).json({
      message: ["Something went wrong. Try again later.", 409, "ERROR"],
    });
  }
};

/*
Async Method to delete user event on the database
*/
export const deleteEvent = async (req, res) => {
  const { userId, id } = req.body;
  try {
    await Event.deleteOne({ userId: userId, id: id });
    res.status(200).json({ message: "Event Deleted Sucessfully" });
  } catch (error) {
    return res.status(404).json({
      message: ["Something went wrong. Try again later.", 404, "ERROR"],
    });
  }
};

/*
Async Method to update user event on the database
*/
export const changeEvent = async (req, res) => {
  const event = req.body;
  const { userId, id } = req.body;
  try {
    await Event.updateOne({ userId: userId, id: id }, { $set: event });
    res.status(200).json({ message: "Event Change Sucessfully" });
  } catch (error) {
    return res.status(404).json({
      message: ["Something went wrong. Try again later.", 404, "ERROR"],
    });
  }
};
