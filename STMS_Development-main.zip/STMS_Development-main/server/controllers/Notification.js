import Notification from "../models/Notification.js";

/*
Async Method to get user notifications from the database
*/
export const getNotifications = async (req, res) => {
  const { userId } = req.body;
  try {
    const notifications = await Notification.find({ userId: userId });
    res.status(200).json(notifications);
  } catch (error) {
    return res.status(404).json({
      message: ["Something went wrong. Try again later.", 404, "ERROR"],
    });
  }
};

/*
Async Method to create user notification on the database
*/
export const createNotification = async (req, res) => {
  const notification = req.body;
  const { userId, id } = req.body;
  try {
    const existingNotification = await Notification.findOne({
      userId: userId,
      id: id,
    });

    if (!existingNotification) {
      const newNotification = new Notification(notification);
      await newNotification.save();
      return res.status(201).json(newNotification);
    }

    res.status(201).json(null);
  } catch (error) {
    return res.status(409).json({
      message: ["Something went wrong. Try again later.", 409, "ERROR"],
    });
  }
};

/*
Async Method to delete user notification on the database
*/
export const deleteNotification = async (req, res) => {
  const { userId, id } = req.body;
  try {
    await Notification.deleteOne({ userId: userId, id: id });
    res.status(200).json({ message: "Notification Deleted Sucessfully" });
  } catch (error) {
    return res.status(404).json({
      message: ["Something went wrong. Try again later.", 404, "ERROR"],
    });
  }
};

/*
Async Method to update user notification on the database
*/
export const changeNotification = async (req, res) => {
  const notification = req.body;
  const { userId, id } = req.body;
  try {
    await Notification.updateOne(
      { userId: userId, id: id },
      { $set: notification }
    );
    res.status(200).json({ message: "Notification Changed Sucessfully" });
  } catch (error) {
    return res.status(404).json({
      message: ["Something went wrong. Try again later.", 404, "ERROR"],
    });
  }
};
