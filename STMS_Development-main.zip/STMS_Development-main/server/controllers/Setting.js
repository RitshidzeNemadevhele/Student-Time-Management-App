import Setting from "../models/Setting.js";

/*
Async Method to create user settings on the database
*/
export const getSettings = async (req, res) => {
  const { userId } = req.body;
  try {
    const settings = await Setting.find({ userId: userId });
    res.status(200).json(settings);
  } catch (error) {
    return res.status(404).json({
      message: ["Something went wrong. Try again later.", 404, "ERROR"],
    });
  }
};

/*
Async Method to create user settings on the database
*/
export const createSettings = async (req, res) => {
  const settings = req.body;
  const { userId } = req.body;
  try {
    const settingsFound = await Setting.findOne({ userId: userId });
    let newSettings = null;
    if (settingsFound) {
    } else {
      newSettings = new Setting(settings);
      await newSettings.save();
    }
    res.status(201).json(["Scheduler Settings Updated Sucessfully", 200, "SUCCESS"]);
  } catch (error) {
    return res.status(409).json({
      message: ["Something went wrong. Try again later.", 409, "ERROR"],
    });
  }
};

/*
Async Method to update user settings on the database
*/
export const changeSettings = async (req, res) => {
  const settings = req.body;
  const { userId } = req.body;
  try {
    await Setting.updateOne({ userId: userId }, { $set: settings });
    return res
      .status(200)
      .json(["Scheduler Settings Updated Sucessfully", 200, "SUCCESS"]);
  } catch (error) {
    return res.status(404).json({
      message: ["Something went wrong. Try again later.", 404, "ERROR"],
    });
  }
};
