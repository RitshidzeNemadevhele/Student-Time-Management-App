import ToDoList from "../models/ToDoList.js";

/*
Async Method to get user todo list from the database
*/
export const getToDoList = async (req, res) => {
  const { userId } = req.body;
  try {
    const toDoLists = await ToDoList.find({ userId: userId });
    res.status(200).json(toDoLists);
  } catch (error) {
    return res.status(404).json({
      message: ["Something went wrong. Try again later.", 404, "ERROR"],
    });
  }
};

/*
Async Method to create user todo list on the database
*/
export const createToDoList = async (req, res) => {
  const todoList = req.body;
  const { userId, _id } = req.body;

  try {
    const todoListFound = await ToDoList.findOne({ userId: userId, _id: _id });
    let newToDoList = null;
    if (todoListFound) {
    } else {
      newToDoList = new ToDoList(todoList);
      await newToDoList.save();
    }
    res.status(201).json(newToDoList);
  } catch (error) {
    return res.status(409).json({
      message: ["Something went wrong. Try again later.", 409, "ERROR"],
    });
  }
};

/*
Async Method to update user todo list on the database
*/
export const changeToDoList = async (req, res) => {
  const todoList = req.body;
  const { userId, _id } = req.body;
  try {
    await ToDoList.updateOne({ userId: userId, _id: _id }, { $set: todoList });
    res.status(200).json({ message: "TodoList Changed Sucessfully" });
  } catch (error) {
    return res.status(404).json({
      message: ["Something went wrong. Try again later.", 404, "ERROR"],
    });
  }
};
