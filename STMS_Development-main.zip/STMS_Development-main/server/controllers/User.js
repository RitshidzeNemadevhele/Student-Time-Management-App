import dotenv from "dotenv";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

import User from "../models/User.js";
dotenv.config({ silent: process.env.NODE_ENV === 'production' });

/*
Async Method to authenticate users - Login
*/
export const login = async (req, res) => {
  const { email, password } = req.body;
  try {
    const existingUser = await User.findOne({ email }); 
    
    if (!existingUser)
      return res.status(404).json({
        message: [
          `User doesn't exist in our database, please sign up.`,
          404,
          "WARNING",
        ],
      });

    var isPasswordCorrect;
    if (existingUser?.password) {
      isPasswordCorrect = await bcrypt.compare(password, existingUser.password);
    } else {
      return res.status(400).json({
        message: [
          `You signed up with Google, please use Google to log in.`,
          400,
          "WARNING",
        ],
      });
    }
    
    if (!isPasswordCorrect)
      return res.status(400).json({
        message: [
          "Incorrect password entered, please try again.",
          400,
          "WARNING",
        ],
      });

    const token = jwt.sign(
      { email: existingUser.email, id: existingUser.id },
      process.env.TOKEN_KEY,
      { expiresIn: "1h" }
    );

    res.status(200).json({ profile: existingUser, token });
  } catch (error) {
    return res.status(500).json({
      message: ["Something went wrong. Try again later.", 500, "ERROR"],
    });
  }
};

/*
Async Method to authenticate users - Signup
*/
export const signup = async (req, res) => {
  const { email, password, username } = req.body;

  try {
    const existingUser = await User.findOne({ email });

    if (existingUser)
      return res.status(400).json({
        message: [
          `User already exist in our database, please log in.`,
          400,
          "WARNING",
        ],
      });

    const hashedPassword = await bcrypt.hash(password, 12);

    const newUser = await User.create({
      email,
      password: hashedPassword,
      name: username,
    });

    const token = jwt.sign(
      { email: newUser.email, id: newUser.id },
      process.env.TOKEN_KEY,
      { expiresIn: "1h" }
    );

    res.status(200).json({ profile: newUser, token });
  } catch (error) {
    return res.status(500).json({
      message: ["Something went wrong. Try again later.", 500, "ERROR"],
    });
  }
};

/*
Async Method to authenticate users - Google Login/Signup
*/
export const googleLoginSignup = async (req, res) => {
  const { googleId, name, email } = req.body;
  try {
    const existingUser = await User.findOne({ email });

    if (!existingUser) {
      await User.create({ googleId, email, name });
    }
    return res.status(200).json({ message: "User Authenticated Sucessfully" });
  } catch (error) {
    return res.status(500).json({
      message: ["Something went wrong. Try again later.", 500, "ERROR"],
    });
  }
};
