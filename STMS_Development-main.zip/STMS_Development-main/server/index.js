import dotenv from "dotenv";
import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import authRoutes from "./routes/Auth.js";
import eventRoutes from "./routes/Event.js";
import todolistRoutes from "./routes/ToDoList.js";
import notificationRoutes from "./routes/Notification.js";
import settingRoutes from "./routes/Setting.js";
dotenv.config({ silent: process.env.NODE_ENV === 'production' });
const app = express();

app.use(express.json({ limit: "30mb", extended: true }));
app.use(express.urlencoded({ limit: "30mb", extended: true }));
app.use(cors());

app.use("/user", authRoutes);
app.use("/User", eventRoutes);
app.use("/User", todolistRoutes);
app.use("/User", notificationRoutes);
app.use("/User", settingRoutes);

const CONNECTION_URL = process.env.MONGODB_CONNECTION_URL;
const PORT = process.env.PORT || 5000;

mongoose
  .connect(CONNECTION_URL, {
    useUnifiedTopology: true,
  })
  .then(() =>
    app.listen(PORT, () => console.log(`Server running on port: ${PORT}`))
  )
  .catch((error) => console.log("ERROR " + error));
