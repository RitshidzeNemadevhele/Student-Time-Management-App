import mongoose from "mongoose";
/*
Event Schema Model
*/
const eventSchema = mongoose.Schema({
  startDate: { type: Date, required: true },
  endDate: { type: Date, required: false },
  title: { type: String, required: false },
  allDay: { type: Boolean, required: true, default: false},
  notes: {type: String, required: false},
  rRule: {type: String, required: false},
  typeId: {type: Number, required: false},
  todoListAddId: {type: Number, required: false},
  userId: { type: String, required: true },
  id: { type: Number },
});

export default mongoose.model("Event", eventSchema);