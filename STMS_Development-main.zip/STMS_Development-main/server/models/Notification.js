import mongoose from "mongoose";

/*
Notification Schema Model
*/
const notificationSchema = mongoose.Schema({
    userId: {type: String, required: true},
    heading: {type: String, required: true},
    secondaryHeading: {type: String, required: true},
    dateSent: {type: Date, required: true},
    notification: {type: String, required: true},
    id: {type: Number, required: true},
    isNotActive: {type: Boolean, required: true}, 
});

export default mongoose.model("Notification", notificationSchema);