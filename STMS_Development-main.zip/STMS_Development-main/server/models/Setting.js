import mongoose from "mongoose";
/*
Setting Schema Model
*/
const settingSchema = mongoose.Schema({
  userId: { type: String, required: true },
  weekStartDay: {
    day: { type: String, required: true, default: "Sunday" },
    index: { type: Number, required: true, default: 0 },
  },
  dayStartTime: {
    time: { type: Date, required: true, default: new Date(2021, 1, 1, 8, 0, 0)},
    decimalTime: { type: Number, required: true, default: 8 },
  },
  dayEndTime: {
    time: { type: Date, required: true, default: new Date(2021, 1, 1, 22, 0, 0)},
    decimalTime: { type: Number, required: true, default: 22 },
  },
  defaultView: {
    view: { type: String, required: true, default: "Work Week" },
    keyText: { type: String, required: true, default: "work-week" },
  },
});

export default mongoose.model("Setting", settingSchema);
