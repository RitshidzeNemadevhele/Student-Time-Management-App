import mongoose from "mongoose";

/*
TodoList Schema Model
*/
const ToDoListSchema = mongoose.Schema({
  userId: { type: String, required: true },
  items: [
    {
      title: { type: String, required: true },
      isComplete: { type: Boolean, required: true },
      id: { type: Number },
    },
  ],
});

export default mongoose.model("ToDoList", ToDoListSchema);
