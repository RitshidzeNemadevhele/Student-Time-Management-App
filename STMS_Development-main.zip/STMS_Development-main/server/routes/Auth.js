import express from "express";
import { googleLoginSignup, login, signup } from "../controllers/User.js";

const router = express.Router();
/*
Authentication Routes
*/
router.post("/login", login);
router.post("/signup", signup);
router.post("/google/login", googleLoginSignup);

export default router;
