import express from "express";
import {
  changeEvent,
  createEvent,
  deleteEvent,
  getEvents,
} from "../controllers/Event.js";

const router = express.Router();
/*
Event Management Routes
*/
router.post("/GetEvents", getEvents);
router.post("/CreateEvent", createEvent);
router.post("/DeleteEvent", deleteEvent);
router.post("/ChangeEvent", changeEvent);

export default router;
