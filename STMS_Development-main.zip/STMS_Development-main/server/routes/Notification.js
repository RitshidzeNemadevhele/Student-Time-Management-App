import express from "express";
import {
  getNotifications,
  createNotification,
  deleteNotification,
  changeNotification,
} from "../controllers/Notification.js";

const router = express.Router();
/*
Notification Management Routes
*/
router.post("/GetNotifications", getNotifications);
router.post("/CreateNotification", createNotification);
router.post("/DeleteNotification", deleteNotification);
router.post("/ChangeNotification", changeNotification);

export default router;
