import express from "express";
import {
  changeSettings,
  createSettings,
  getSettings,
} from "../controllers/Setting.js";

const router = express.Router();
/*
Settings Management Routes
*/
router.post("/GetSettings", getSettings);
router.post("/CreateSettings", createSettings);
router.post("/ChangeSettings", changeSettings);

export default router;