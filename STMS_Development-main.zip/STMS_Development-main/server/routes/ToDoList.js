import express from "express";
import {
  changeToDoList,
  createToDoList,
  getToDoList,
} from "../controllers/ToDoList.js";

const router = express.Router();
/*
Todo List Management Routes
*/
router.post("/GetToDoList", getToDoList);
router.post("/CreateToDoList", createToDoList);
router.post("/ChangeToDoList", changeToDoList);

export default router;
